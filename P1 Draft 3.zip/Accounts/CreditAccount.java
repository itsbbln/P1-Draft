package Accounts;

import Bank.Bank;

public class CreditAccount extends Account implements Payment, Recompense {
    private double creditLimit;
    private double currentDebt;

    // Constructor
    public CreditAccount(Bank bank, String accountNumber, String ownerLName, String ownerFName, String ownerEmail, String pin, double creditLimit) {
        super(bank, accountNumber, ownerLName, ownerFName, ownerEmail, pin);
        this.creditLimit = creditLimit;
        this.currentDebt = 0; // Initially no debt
    }

    public String getLoanStatement() {
        return "Loan Statement:\n" +
                "Account: " + getAccountNumber() + "\n" +
                "Owner: " + getOwnerFullName() + "\n" +
                "Credit Limit: $" + creditLimit + "\n" +
                "Current Debt: $" + currentDebt + "\n" ;
    }

    private void adjustLoanAmount(double amountAdjustment) {
        if (canCredit(amountAdjustment)) {
            this.currentDebt += amountAdjustment;
        } else {
            System.out.println("\nError: Exceeds credit limit.");
        }
    }

    private boolean canCredit(double amountAdjustment) {
        return (currentDebt + amountAdjustment) <= creditLimit;
    }

    // Implement Payment interface
    @Override
    public void makePayment(double amount) {
        if (amount > 0 && amount <= currentDebt) {
            adjustLoanAmount(-amount); // Reduce debt
            String description = "\nPayment of $" + amount + " made. Remaining Debt: $" + currentDebt;
            addNewTransaction(getAccountNumber(), Transaction.Transactions.Payment, description);
            System.out.println(description);
        } else {
            System.out.println("\nInvalid payment amount.");
        }
    }

    // Implemented from abstract method in Account
    @Override
    public String toString() {
        return "Account Number: " + getAccountNumber() +
                "\nOwner: " + getOwnerFullName() +
                "\nCredit Limit: $" + creditLimit +
                "Current Debt: $" + currentDebt;
    }

    @Override
    public void transferFunds(double amount) {
        System.out.println("\nError: Credit accounts cannot transfer funds directly.");
    }

    @Override
    public boolean transfer(Bank bank, Account account, double amount) throws IllegalAccountType {
        return false;
    }

    @Override
    public boolean transfer(Account account, double amount) throws IllegalAccountType {
        return false;
    }

    @Override
    public boolean pay(Account account, double amount) throws IllegalAccountType {
        return false;
    }

    @Override
    public boolean recompense(double amount) {
        if (amount > 0 && amount <= currentDebt) {
            adjustLoanAmount(-amount); // Reduce debt
            String description = "Recompense of $" + amount + " applied. New Debt: $" + currentDebt;
            addNewTransaction(getAccountNumber(), Transaction.Transactions.Recompense, description);
            System.out.println(description);
            return true;
        } else {
            System.out.println("\nRecompense failed. Amount exceeds current debt.");
            return false;
        }
    }

    public double getCurrentDebt() {
        return currentDebt;
    }

}
