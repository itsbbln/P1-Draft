package Accounts;
import Bank.Bank;

public class SavingsAccount extends Account implements Deposit, Withdrawal, FundTransfer {
    private double balance;

    // Constructor
    public SavingsAccount(Bank bank, String accountNumber, String ownerLName, String ownerFName, String ownerEmail, String pin, double balance) {
        super(bank, accountNumber, ownerLName, ownerFName, ownerEmail, pin);
        this.balance = balance;
    }

    // Get balance statement
    public String getAccountBalanceStatement() {
        return "$" + balance;
    }

    // Check if enough balance for withdrawal
    private boolean hasEnoughBalance(double amount) {
        return balance >= amount;
    }

    // Handle insufficient balance scenario
    private void insufficientBalance() {
        System.out.println("\nError: Insufficient balance for this transaction.");
    }

    // Adjust balance (for deposits/withdrawals)
    private void adjustAccountBalance(double amount) {
        this.balance += amount;
    }

    // Implemented from abstract method in Account
    @Override
    public String toString() {
        return "\nAccount Number: " + getAccountNumber() +
         "\nOwner: " + getOwnerFullName() + "\nBalance: $" + balance + "]";
    }

    @Override
    public boolean deposit(double amount) {
        if (amount > 0) {
            adjustAccountBalance(amount);
            addNewTransaction(ACCOUNTNUMBER, Transaction.Transactions.Deposit, "Deposited $" + amount);
            System.out.println("Deposited: $" + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
        return false;
    }

    @Override
    public boolean cashDeposit(double amount) {
        if (amount > 0) {
            adjustAccountBalance(amount);
            addNewTransaction(ACCOUNTNUMBER, Transaction.Transactions.Deposit, "Cash deposited: $" + amount);
            return true;
        }
        return false;
    }

    @Override
    public boolean withdraw(double amount) {
        if (hasEnoughBalance(amount)) {
            adjustAccountBalance(-amount);
            addNewTransaction(ACCOUNTNUMBER, Transaction.Transactions.Withdraw, "Withdrawn $" + amount);
            System.out.println("Withdraw: $" + amount);
        } else {
            insufficientBalance();
        }
        return false;
    }

    @Override
    public boolean withdrawal(double amount) {
        if (hasEnoughBalance(amount)) {
            adjustAccountBalance(-amount);
            addNewTransaction(ACCOUNTNUMBER, Transaction.Transactions.Withdraw, "Withdrawn $" + amount);
            return true;
        }
        return false;
    }

    @Override
    public void transferFunds(double amount) {
        System.out.println("\nFund transfer requires recipient details.");
    }

    @Override
    public boolean transfer(Account recipient, double amount) throws IllegalAccountType {
        if (!(recipient instanceof SavingsAccount)) {
            throw new IllegalAccountType("Invalid recipient. Only savings accounts are allowed.");
        }

        if (withdraw(amount)) {
            ((SavingsAccount) recipient).deposit(amount);

            addNewTransaction(ACCOUNTNUMBER, Transaction.Transactions.FundTransfer,
                    "Transferred $" + amount + " to " + recipient.getAccountNumber());

            recipient.addNewTransaction(recipient.getAccountNumber(), Transaction.Transactions.FundTransfer,
                    "Received $" + amount + " from " + ACCOUNTNUMBER);

            System.out.println("Transfer successful: $" + amount + " sent to " + recipient.getAccountNumber());
            return true;
        }
        System.out.println("Transfer failed.");
        return false;
    }

    @Override
    public boolean transfer(Bank bank, Account account, double amount) {
        return false;
    }
}


