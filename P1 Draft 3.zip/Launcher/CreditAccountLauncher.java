package Launcher;
import Accounts.Account;
import Accounts.CreditAccount;

public class CreditAccountLauncher extends AccountLauncher {
    public void creditAccountInit() {
        System.out.println("Credit Account operations initialized.");
        // Additional initialization logic can be placed here.
    }

    private void creditPaymentProcess(String recipientAccountNumber, double amount) {
        CreditAccount creditAccount = getLoggedAccount();
        if (creditAccount == null) {
            System.out.println("No logged-in credit account.");
            return;
        }

        // Perform payment (assuming a method like `makePayment` exists in CreditAccount)
        creditAccount.makePayment(amount);
        System.out.println("\nCredit payment of $" + amount + " sent to account " + recipientAccountNumber);
    }

    private void creditRecompenseProcess(double amount) {
        CreditAccount creditAccount = getLoggedAccount();
        if (creditAccount == null) {
            System.out.println("No logged-in credit account.");
            return;
        }

        if (amount <= 0 || amount > creditAccount.getCurrentDebt()) {
            System.out.println("Invalid recompense amount.");
            return;
        }

        creditAccount.recompense(amount);
        System.out.println("\nCredit recompense of " + amount + " processed. Remaining debt: " + creditAccount.getCurrentDebt());
    }

    protected CreditAccount getLoggedAccount() {
        return (CreditAccount) super.getLoggedAccount();
    }

    @Override
    public void setLoggedSession(Account account) {
        super.setLoggedSession(account);
    }

    public void getCreditRecompenseProcess(double amount) {
        creditRecompenseProcess(amount);
    }
}
