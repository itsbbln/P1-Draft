package Launcher;

import Accounts.Account;
import Accounts.SavingsAccount;

public class SavingsAccountLauncher extends AccountLauncher{
    public void savingsAccountInit() {
        System.out.println("Savings Account operations initialized.");
        // Additional initialization logic can be placed here.
    }

    private void depositProcess(double amount) {
        SavingsAccount account = getLoggedAccount();
        if (account == null) {
            System.out.println("\nNo logged-in savings account.");
            return;
        }

        if (amount <= 0) {
            System.out.println("\nInvalid deposit amount.");
            return;
        }

        account.deposit(amount);
        System.out.println("\nDeposit successful. New balance: " + account.getAccountBalanceStatement());
    }

    private void withdrawProcess(double amount) {
        SavingsAccount account = getLoggedAccount();
        if (account == null) {
            System.out.println("\nNo logged-in savings account.");
            return;
        }

        if ((amount <= 0) || amount > Double.parseDouble(account.getAccountBalanceStatement().replace("$", ""))){
            System.out.println("\nInvalid withdrawal amount.");
            return;
        }

        account.withdraw(amount);
        System.out.println("\nWithdrawal successful. New balance: " + account.getAccountBalanceStatement());
    }

    private void fundTransferProcess(SavingsAccount recipient, double amount) {
        SavingsAccount sender = getLoggedAccount();
        if (sender == null) {
            System.out.println("\nNo logged-in savings account.");
            return;
        }

        if ((recipient == null) || (amount <= 0) || (amount > Double.parseDouble(sender.getAccountBalanceStatement().replace("$", "")))) {
            System.out.println("\nInvalid transfer request.");
            return;
        }

        sender.withdraw(amount);
        recipient.deposit(amount);
        System.out.println("\nFund transfer successful. Sent " + amount + " to " + recipient.getAccountNumber());
    }

    protected SavingsAccount getLoggedAccount() {
        return (SavingsAccount) super.getLoggedAccount();
    }

    public void getDepositProcess(double amount) {
        depositProcess(amount);
    }

    public void getWithdrawProcess(double amount) {
        withdrawProcess(amount);
    }

    @Override
    public void setLoggedSession(Account account) {
        super.setLoggedSession(account);
    }

    public void getFundTransferProcess(SavingsAccount recipient, double amount) {
        fundTransferProcess(recipient, amount);
    }
}
