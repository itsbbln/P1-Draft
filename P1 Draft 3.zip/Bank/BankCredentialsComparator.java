package Bank;
import Accounts.Account;

import java.util.Comparator;

public class BankCredentialsComparator implements Comparator<Account> {

    @Override
    public int compare(Account a1, Account a2) {
        int lastNameComparison = a1.getOwnerLName().compareTo(a2.getOwnerLName());
        if (lastNameComparison != 0) {
            return lastNameComparison;
        }

        int firstNameComparison = a1.getOwnerFName().compareTo(a2.getOwnerFName());
        if (firstNameComparison != 0) {
            return firstNameComparison;
        }

        return a1.getPin().compareTo(a2.getPin());
    }

    // New method to check if an account with the same credentials exists
    public boolean compareCredentials(String lName, String fName, String pin, Account account) {
        return account.getOwnerLName().equals(lName) &&
                account.getOwnerFName().equals(fName) &&
                account.getPin().equals(pin);
    }
}
