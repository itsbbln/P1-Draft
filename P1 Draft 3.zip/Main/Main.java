package Main;
import java.util.Scanner;

import Accounts.CreditAccount;
import Accounts.IllegalAccountType;
import Bank.Bank;
import Bank.BankComparator;
import Bank.BankCredentialsComparator;
import Launcher.AccountLauncher;
import Launcher.BankLauncher;
import Accounts.Account;
import Accounts.SavingsAccount;
import Launcher.CreditAccountLauncher;
import Launcher.SavingsAccountLauncher;

public class Main
{

    private static final Scanner input = new Scanner(System.in);
    /**
     * Option field used when selection options during menu prompts. Do not create a different
     * option variable in menus. Just use this instead. <br>
     * As to how to utilize Field objects properly, refer to the following:
     *
     * @see #prompt(String, boolean)
     * @see #setOption() How Field objects are used.
     */
    public static Field<Integer, Integer> option = new Field<Integer, Integer>("Option",
            Integer.class, -1, new Field.IntegerFieldValidator());

    public static void main(String[] args) throws IllegalAccountType {
        while (true)
        {
            showMenuHeader("Main Menu");
            showMenu(1);
            setOption();
            // Account Option
            if (getOption() == 1) {
                AccountLauncher accountLauncher = new AccountLauncher();

                while (true) {
                    // READ ME: Refer to this code block on how one should properly utilize
                    // showMenuHeader(), showMenu(),
                    // setOption(), and getOption() methods...
                    showMenuHeader("Account Login Menu");
                    showMenu(2, 1);
                    setOption();
                    // TODO: Complete this portion

                    if (getOption() == 1) {

                        // Prompt for account login details
                        System.out.println("Enter Bank Name: ");
                        String bankName = input.nextLine();
                        Bank selectedBank = accountLauncher.getSelectBank(bankName);

                        if (selectedBank == null) {
                            System.out.println("\nBank not found. Try again.");
                            continue;
                        }

                        while (true) {
                            showMenuHeader("Select Account Type");
                            showMenu(33, 1);
                            setOption();

                            if (getOption() == 0) {
                                System.out.println("\nGo back to main menu.");
                                break;
                            }

                            if (accountLauncher.getIsLogged()) {
                                System.out.println("You are already logged in.");
                                continue;
                            }

                            System.out.print("Enter Account Number: ");
                            String accountNumber = input.nextLine();
                            System.out.print("Enter PIN: ");
                            String pin = input.nextLine();

                            accountLauncher.accountLogin(accountNumber, pin);
                            Account selectedAccount = accountLauncher.fetchLoggedAccount();

                            if (getOption() == 1) {

                                if (!(selectedAccount instanceof CreditAccount account)) {
                                    System.out.println("\nNo credit account found.");
                                    continue;
                                }

                                CreditAccountLauncher creditLauncher = new CreditAccountLauncher();
                                creditLauncher.setLoggedSession(account);
                                System.out.println("Successfully logged into Credit Account: " + accountNumber);

                                while (true) {
                                    showMenuHeader("Credit Account Menu");
                                    showMenu(41, 1);
                                    setOption();

                                    if (getOption() == 1) {
                                        System.out.println(account.getLoanStatement());

                                    } else if (getOption() == 2) { // Pay
                                        System.out.print("Enter amount to pay: ");
                                        double amount = input.nextDouble();
                                        input.nextLine();
                                        account.makePayment(amount);

                                    } else if (getOption() == 3) { // Recompense
                                        System.out.print("Enter recompense amount: ");
                                        double amount = input.nextDouble();
                                        input.nextLine();
                                        creditLauncher.getCreditRecompenseProcess(amount);

                                    } else if (getOption() == 4) { // Show Transactions
                                        System.out.println("\nTransaction History:");
                                        System.out.println(selectedAccount.getTransactionsInfo());

                                    } else if (getOption() == 5) {
                                        System.out.println("\nLogging out of credit account.");
                                        accountLauncher.getDestroyLoggedSession();
                                        break;
                                    }
                                }
                            }
                            else if (getOption() == 2) { // Savings Account
                                if (!(selectedAccount instanceof SavingsAccount account)) {
                                    System.out.println("\nNo savings account found.");
                                    continue;
                                }

                                SavingsAccountLauncher savingsLauncher = new SavingsAccountLauncher();
                                savingsLauncher.setLoggedSession(account);
                                System.out.println("\nSuccessfully logged into Savings Account: " + accountNumber);

                                while (true) {
                                    showMenuHeader("Savings Account Menu");
                                    showMenu(51, 1);
                                    setOption();

                                    if (getOption() == 1) {
                                        System.out.println("\nCurrent Balance: " + account.getAccountBalanceStatement());

                                    } else if (getOption() == 2) {
                                        double depositLimit = selectedBank.getDepositLimit();
                                        System.out.print("Enter deposit amount: ");
                                        double amount = input.nextDouble();
                                        input.nextLine();

                                        if (amount > depositLimit) {
                                            System.out.println("\nDeposit failed! Amount exceeds the deposit limit of $" + depositLimit);
                                        } else {
                                            savingsLauncher.getDepositProcess(amount);
                                        }

                                    } else if (getOption() == 3) {
                                        double withdrawLimit = selectedBank.getWithdrawLimit();
                                        System.out.print("Enter withdrawal amount: ");
                                        double amount = input.nextDouble();
                                        input.nextLine();

                                        if (amount > withdrawLimit) {
                                            System.out.println("\nWithdrawal failed! Amount exceeds the withdrawal limit of $" + withdrawLimit);
                                        } else {
                                            savingsLauncher.getWithdrawProcess(amount);
                                        }

                                    } else if (getOption() == 4) {  // Fund Transfer
                                        System.out.print("Enter recipient account number: ");
                                        String recipientNumber = input.nextLine();
                                        Account recipientAccount = selectedBank.getBankAccount(recipientNumber);

                                        if (!(recipientAccount instanceof SavingsAccount)) {
                                            System.out.println("\nInvalid recipient. Only savings accounts are allowed.");
                                        }else {
                                            System.out.print("Enter transfer amount: ");
                                            double amount = input.nextDouble();
                                            input.nextLine();

                                            double processingFee =selectedBank.getProcessingFee();
                                            BankComparator bankComparator = new BankComparator();

                                            if (bankComparator.compare(selectedBank, recipientAccount.getBank()) == 0) {
                                                // Internal transfer (no processing fee)
                                                if (selectedAccount.transfer(recipientAccount, amount)) {
                                                    System.out.println("Transfer successful!");
                                                } else {
                                                    System.out.println("Transfer failed.");
                                                }
                                            } else {
                                                // External transfer (apply processing fee)
                                                double totalAmount = amount + processingFee;
                                                if (selectedAccount.transfer(recipientAccount, totalAmount)) {
                                                    System.out.println("\nTransfer of $" + amount + " to " + recipientAccount.getAccountNumber() + " was successful. A processing fee of $" + processingFee + " was applied.");
                                                } else {
                                                    System.out.println("\nTransfer failed. Please check your balance and try again.");
                                                }
                                            }
                                        }

                                    } else if (getOption() == 5) {
                                        System.out.println("\nTransaction History:");
                                        System.out.println(selectedAccount.getTransactionsInfo());
                                    }
                                    else if (getOption() == 6) {
                                        System.out.println("\nLogging out of savings account");
                                        accountLauncher.getDestroyLoggedSession();
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else if (getOption() == 2) {
                        break;
                    }
                }
            }
            // Bank Option
            else if (getOption() == 2)
            {
                // TODO: Complete Bank option
                while (true) {
                    showMenuHeader("Bank Login Menu");
                    showMenu(3, 1);
                    setOption();

                    if (getOption() == 1) {
                        // Prompt for bank login details
                        System.out.print("\nEnter Bank Name to login: ");
                        String bankName = input.nextLine();
                        System.out.print("Enter Passcode: ");
                        String passcode = input.nextLine();

                        if (BankLauncher.isLoggedIn()) {
                            System.out.println("\nYou are already logged in.");
                            continue;
                        }

                        if (!BankLauncher.bankLogin(bankName, passcode)) {
                            System.out.println("\nInvalid bank name or passcode!");
                            continue;
                        }

                        System.out.println("\nSuccessfully logged into " + bankName + "\n");
                        Bank selectedBank = BankLauncher.getBank(new BankComparator(), new Bank(0, bankName, "", 0, 0, 0, 0));

                        if (selectedBank == null) {
                            System.out.println("Bank not found!");
                            continue;
                        }
                        BankLauncher.LogSession(selectedBank);

                        while (true) {
                            showMenuHeader("Bank Menu");
                            showMenu(31, 1);
                            setOption();

                            if (getOption() == 1) {
                                while (true) {
                                    showMenuHeader("Select Account Type to Display:");
                                    showMenu(32, 1);
                                    setOption();

                                    if (getOption() == 1) {
                                        System.out.println("\n--- Credit Accounts in " + bankName + " ---");
                                        BankLauncher.displayAccounts();

                                    } else if (getOption() == 2) {
                                        System.out.println("\n--- Savings Accounts in " + bankName + " ---");
                                        BankLauncher.displayAccounts();

                                    } else if (getOption() == 3) {
                                        System.out.println("\n--- All Accounts in " + bankName + " ---");
                                        BankLauncher.displayAccounts();

                                    } else if (getOption() == 4) {
                                        break; // Go back to Bank Menu
                                    }
                                }
                            }
                            else if (getOption() == 2) {
                                while (true) {
                                    showMenuHeader("Create New Account");
                                    showMenu(33, 1);
                                    setOption();

                                    if (getOption() == 0) {
                                        System.out.println("\nGo back to bank menu.");
                                        break;
                                    }

                                    // Create new account
                                    System.out.print("\nEnter Account Number: ");
                                    String newAccountNumber = input.nextLine();


                                    if (BankLauncher.findAccount(newAccountNumber) != null) {
                                        System.out.println("\nAccount creation failed! Account number already exists.");
                                        continue;
                                    }

                                    System.out.print("Enter Last Name: ");
                                    String ownerLName = input.nextLine();
                                    System.out.print("Enter First Name: ");
                                    String ownerFName = input.nextLine();
                                    System.out.print("Enter Email: ");
                                    String ownerEmail = input.nextLine();
                                    System.out.print("Enter PIN: ");
                                    String pin = input.nextLine();

                                    // Use the comparator to check for duplicate credentials
                                    BankCredentialsComparator comparator = new BankCredentialsComparator();

                                    for (Account account : selectedBank.getBankAccounts()) { // Ensure this method returns a list of accounts
                                        if (comparator.compareCredentials(ownerLName, ownerFName, pin, account)) {
                                            System.out.println("\nAccount creation failed! Duplicate credentials.");
                                        }
                                    }

                                    if (getOption() == 1) {
                                        double creditLimit = selectedBank.getCreditLimit();
                                        BankLauncher.createNewAccount(new CreditAccount(selectedBank, newAccountNumber, ownerLName, ownerFName, ownerEmail, pin, creditLimit));

                                    } else if (getOption() == 2) {

                                        System.out.print("Enter Initial Deposit: ");
                                        double initialDeposit = input.nextDouble();
                                        input.nextLine();

                                        BankLauncher.createNewAccount(new SavingsAccount(selectedBank, newAccountNumber, ownerLName, ownerFName, ownerEmail, pin, initialDeposit));
                                    } else {
                                        System.out.println("Invalid account type!");
                                    }
                                }
                            }
                            else if (getOption() == 3){
                                BankLauncher.logout();
                                break;
                            }
                            else{
                                System.out.println("Invalid bank name or passcode!");
                            }
                        }
                    }
                    else if (getOption() == 2) {
                        break; // Go back to Main Menu
                    }
                }
            }
            // Create New Bank
            else if (getOption() == 3)
            {
                // TODO: Complete this portion...

                System.out.println("\nAvailable Banks:");
                BankLauncher.showBanksMenu();

                System.out.print("\nEnter Bank Name: ");
                String name = input.nextLine();

                // Use BankComparator to check if the bank name already exists
                Bank tempBank = new Bank(0, name, "", 0, 0, 0, 0);
                BankComparator comparator = new BankComparator();

                boolean exists = BankLauncher.getBank(comparator, tempBank) != null; // Check if bank exists

                if (exists) {
                    System.out.println("Bank already exists. Please enter a different name.");
                } else {
                    System.out.print("Enter Passcode: ");
                    String passcode = input.nextLine();
                    System.out.print("Enter Deposit Limit: ");
                    double depositLimit = input.nextDouble();
                    System.out.print("Enter Withdraw Limit: ");
                    double withdrawLimit = input.nextDouble();
                    System.out.print("Enter Credit Limit: ");
                    double creditLimit = input.nextDouble();
                    System.out.print("Enter Processing Fee: ");
                    double processingFee = input.nextDouble();
                    input.nextLine();

                    BankLauncher.createNewBank(name, passcode, depositLimit, withdrawLimit, creditLimit, processingFee);
                    System.out.println("\nBank created successfully!");
                    System.out.println("Total Banks: " + BankLauncher.bankSize());
                }
            }
            else if (getOption() == 4) {
                System.out.println("Exiting. Thank you for banking!\n");
                break;
            }
            else
            {
                System.out.println("Invalid option!");
            }
        }
    }

    /**
     * Show menu based on index given. <br>
     * Refer to Menu enum for more info about menu indexes. <br>
     * Use this method if you want a single menu option every line.
     *
     * @param menuIdx Main.Menu index to be shown
     */
    public static void showMenu(int menuIdx)
    {
        showMenu(menuIdx, 1);
    }

    /**
     * Show menu based on index given. <br>
     * Refer to Menu enum for more info about menu indexes.
     *
     * @param menuIdx Main.Menu index to be shown
     * @param inlineTexts Number of menu options in a single line. Set to 1 if you only want a
     *        single menu option every line.
     * @see Menu
     */
    public static void showMenu(int menuIdx, int inlineTexts)
    {
        String[] menu = Menu.getMenuOptions(menuIdx);
        if (menu == null)
        {
            System.out.println("Invalid menu index given!");
        }
        else
        {
            String space = inlineTexts == 0 ? "" : "%-20s";
            String fmt = "[%d] " + space;
            int count = 0;
            for (String s : menu)
            {
                count++;
                System.out.printf(fmt, count, s);
                if (count % inlineTexts == 0)
                {
                    System.out.println();
                }
            }
        }
    }

    /**
     * Prompt some input to the user. Only receives on non-space containing String. This string can
     * then be parsed into targeted data type using DataTypeWrapper.parse() method.
     *
     * @param phrase Prompt to the user.
     * @param inlineInput A flag to ask if the input is just one entire String or receive an entire
     *        line input. <br>
     *        Set to <b>true</b> if receiving only one String input without spaces. <br>
     *        Set to <b>false</b> if receiving an entire line of String input.
     * @return Value of the user's input.
     * @see Field#setFieldValue(String, boolean) How prompt is utilized in Field.
     */
    public static String prompt(String phrase, boolean inlineInput)
    {
        System.out.print(phrase);
        if (inlineInput)
        {
            String val = input.next();
            input.nextLine();
            return val;
        }
        return input.nextLine();
    }

    /**
     * Prompts user to set an option based on menu outputted.
     *
     * @throws NumberFormatException May happen if the user attempts to input something other than
     *         numbers.
     */
    public static void setOption() throws NumberFormatException
    {
        option.setFieldValue("\nSelect an option: ");
    }

    /**
     * @return Recently inputted option by the user.
     */
    public static int getOption()
    {
        return Main.option.getFieldValue();
    }

    /**
     * Used for printing the header whenever a new menu is accessed.
     *
     * @param menuTitle Title of the menu to be outputted.
     */
    public static void showMenuHeader(String menuTitle)
    {
        System.out.printf("\n<---- %s ----->\n", menuTitle);
    }
}
