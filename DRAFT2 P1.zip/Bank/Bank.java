package Bank;
import Accounts.Account;
import Accounts.CreditAccount;
import Accounts.SavingsAccount;

import java.util.ArrayList;

public class Bank {
    private int ID;
    private String name, passcode;
    private double DEPOSITLIMIT, WITHDRAWLIMIT, CREDITLIMIT;
    private double processingFee;
    private ArrayList<Account> BANKACCOUNTS;

    //Overloaded Constructor
    public Bank(int ID, String name, String passcode) {
        this(ID, name, passcode, 0, 0, 0, 0);
    }

    // Constructor
    public Bank(int ID, String name, String passcode, double depositLimit, double withdrawLimit, double creditLimit, double processingFee) {
        this.ID = ID;
        this.name = name;
        this.passcode = passcode;
        this.DEPOSITLIMIT = depositLimit;
        this.WITHDRAWLIMIT = withdrawLimit;
        this.CREDITLIMIT = creditLimit;
        this.processingFee = processingFee;
        this.BANKACCOUNTS = new ArrayList<>();
    }

    // Show accounts by type
    public <T> void showAccounts(Class<? extends Account> accountType) {
        for (Account acc : BANKACCOUNTS) {
            if (accountType.isInstance(acc)) {
                System.out.println(acc);
            }
        }
    }

    // Retrieve an account by bank and account number
    public Account getBankAccount(String accountNum) {
        if (this.BANKACCOUNTS == null) return null; // Avoid NullPointerException

        for (Account acc : this.BANKACCOUNTS) {
            if (String.valueOf(acc.ACCOUNTNUMBER).equals(accountNum)) { // Ensure comparison works
                return acc;
            }
        }
        return null;
        /*for (Account acc : this.BANKACCOUNTS) {
            if (acc.ACCOUNTNUMBER.equals(accountNum)) {
                return acc;
            }
        }
        return null; // Account not found
         */
    }

    // Create a new Credit Account
    public CreditAccount createNewCreditAccount(String accountNumber, String ownerLName, String ownerFName, String ownerEmail, String pin) {
        CreditAccount newAccount = new CreditAccount(this, accountNumber, ownerLName, ownerFName, ownerEmail, pin, CREDITLIMIT);
        addNewAccount(newAccount); // Add the account to the bank's account list
        System.out.println("Credit account created successfully! Account Number: " + accountNumber);
        return newAccount;
    }

    // Create a new Savings Account
    public SavingsAccount createNewSavingsAccount(String accountNumber, String ownerLName, String ownerFName, String ownerEmail, String pin, double initialDeposit) {
        SavingsAccount newAccount = new SavingsAccount(this, accountNumber, ownerLName, ownerFName, ownerEmail, pin, initialDeposit);
        addNewAccount(newAccount); // Add the account to the bank's account list
        System.out.println("Savings account created successfully! Account Number: " + accountNumber);
        return newAccount;
    }

    // Add an existing account
    public void addNewAccount(Account account) {
        BANKACCOUNTS.add(account);
    }

    // Static method to check if an account exists
    public static boolean accountExist(Bank bank, String accountNumber) {
        for (Account account : bank.BANKACCOUNTS) { // Iterate through all banks
            if (account.ACCOUNTNUMBER.equals(accountNumber)) {
                return true; // Account exists
            }
        }
        return false; // Account does not exist
    }

    // Getter Methods

    // Getter for BANKACCOUNTS
    public ArrayList<Account> getBankAccounts() {
        return BANKACCOUNTS;
    }
    public int getID(){
        return ID;
    }

    public String getName() {
        return name;
    }

    public String getPasscode() {
        return passcode;
    }

    public double getDepositLimit() {
        return DEPOSITLIMIT;
    }

    public double getWithdrawLimit() {
        return WITHDRAWLIMIT;
    }

    public double getCreditLimit() {
        return CREDITLIMIT;
    }

    public double getProcessingFee() {
        return processingFee;
    }

    public String toString() {
        return "Bank Name: " + name + " | ID: " + ID;
    }
}
