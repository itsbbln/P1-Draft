package Bank;

public class BankCredentialsComparator implements Comparator<Bank> {
    private Bank b1;
    private Bank b2;

    // Compare banks by name and passcode
    public int compare(Bank b1, Bank b2) {
        int nameComparison = b1.getName().compareTo(b2.getName());
        if (nameComparison != 0) {
            return nameComparison;
        }
        return b1.getPasscode().compareTo(b2.getPasscode());
    }
}
