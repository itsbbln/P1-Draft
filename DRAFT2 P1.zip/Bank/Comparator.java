package Bank;

public interface Comparator<B> {
    int compare(Bank b1, Bank b2);
}
