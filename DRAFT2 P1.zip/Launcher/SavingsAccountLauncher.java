package Launcher;

import Accounts.Account;
import Accounts.SavingsAccount;

public class SavingsAccountLauncher extends AccountLauncher{
    public void savingsAccountInit() {
        System.out.println("Savings Account operations initialized.");
        // Additional initialization logic can be placed here.
    }

    private void depositProcess(double amount) {
        SavingsAccount account = getLoggedAccount();
        if (account == null) {
            System.out.println("No logged-in savings account.");
            return;
        }

        if (amount <= 0) {
            System.out.println("Invalid deposit amount.");
            return;
        }

        account.deposit(amount);
        System.out.println("Deposit successful. New balance: " + account.getAccountBalanceStatement());
    }

    private void withdrawProcess(double amount) {
        SavingsAccount account = getLoggedAccount();
        if (account == null) {
            System.out.println("No logged-in savings account.");
            return;
        }

        if ((amount <= 0) || amount > Double.parseDouble(account.getAccountBalanceStatement())){
            System.out.println("Invalid withdrawal amount.");
            return;
        }

        account.withdraw(amount);
        System.out.println("Withdrawal successful. New balance: " + account.getAccountBalanceStatement());
    }

    private void fundTransferProcess(SavingsAccount recipient, double amount) {
        SavingsAccount sender = getLoggedAccount();
        if (sender == null) {
            System.out.println("No logged-in savings account.");
            return;
        }

        if ((recipient == null) || (amount <= 0) || (amount > Double.parseDouble(sender.getAccountBalanceStatement()))) {
            System.out.println("Invalid transfer request.");
            return;
        }

        sender.withdraw(amount);
        recipient.deposit(amount);
        System.out.println("Fund transfer successful. Sent " + amount + " to " + recipient.ACCOUNTNUMBER);
    }

    protected SavingsAccount getLoggedAccount() {
        return (SavingsAccount) super.getLoggedAccount();
    }

    public void getDepositProcess(double amount) {
        depositProcess(amount);
    }

    public void getWithdrawProcess(double amount) {
        withdrawProcess(amount);
    }

    @Override
    public void setLoggedAccount(Account account) {
        super.setLoggedAccount(account);
    }

    public void getFundTransferProcess(SavingsAccount recipient, double amount) {
        fundTransferProcess(recipient, amount);
    }
}
