package Launcher;
import Accounts.Account;
import Bank.Bank;

import java.util.ArrayList;
import java.util.Comparator;


public class BankLauncher {
    private static ArrayList<Bank> BANKS = new ArrayList<>();
    private static Bank loggedBank = null;

    // Check if a user is logged in
    public static boolean isLoggedIn() {
        return loggedBank != null;
    }

    public static void bankInit() {
        // Implementation if needed
    }

    // Show all accounts of the logged-in bank
    private static void showAccounts() {
        if (loggedBank != null) {
            loggedBank.showAccounts(Account.class);
        } else {
            System.out.println("No bank is currently logged in.");
        }
    }

    // Add a new account to the logged-in bank
    private static void newAccounts(Account account) {
        if (loggedBank != null) {
            loggedBank.addNewAccount(account);
        } else {
            System.out.println("No bank is currently logged in.");
        }
    }

    // Bank login process
    public static boolean bankLogin(String name, String passcode) {
        for (Bank bank : BANKS) {
            if (bank.getName().equals(name) && bank.getPasscode().equals(passcode)) {
                loggedBank = bank;
                return true;
            }
        }
        return false; // Login failed
    }

    // Set logged-in bank
    private static void setLogSession(Bank b) {
        loggedBank = b;
    }

    // Show all banks
    public static void showBanksMenu() {
        for (Bank bank : BANKS) {
            System.out.println(bank);
        }
    }

    // Logout from the bank
    public static void logout() {
        loggedBank = null;
    }

    // Create a new bank
    public static void createNewBank(String name, String passcode, double depositLimit, double withdrawLimit, double creditLimit, double processingFee) {
        int id = BANKS.size() + 1; // Assigning unique ID based on size
        Bank newBank = new Bank(id, name, passcode, depositLimit, withdrawLimit, creditLimit, processingFee);
        BANKS.add(newBank);
    }

    // Add a bank to the list
    private static void addBank(Bank b) {
        BANKS.add(b);
    }

    // Get a bank using a comparator
    public static Bank getBank(Comparator<Bank> comparator, Bank bank) {
        for (Bank b : BANKS) {
            if (comparator.compare(b, bank) == 0) {
                return b;
            }
        }
        return null;
    }

    // Find an account by account number
    public static Account findAccount(String accountNum) {
        if (loggedBank != null) {
            return loggedBank.getBankAccount(accountNum);
        }
        return null;
    }

    // Get total number of banks
    public static int bankSize() {
        return BANKS.size();
    }

}
