package Launcher;
import Accounts.Account;
import Accounts.CreditAccount;

public class CreditAccountLauncher extends AccountLauncher {
    public void creditAccountInit() {
        System.out.println("Credit Account operations initialized.");
        // Additional initialization logic can be placed here.
    }

    private void creditPaymentProcess(String recipientAccountNumber, double amount) {
        CreditAccount creditAccount = getLoggedAccount();
        if (creditAccount == null) {
            System.out.println("No logged-in credit account.");
            return;
        }

        // Validate payment amount
        if (amount <= 0 || amount > creditAccount.getAvailableCredit()) {
            System.out.println("Invalid credit payment amount.");
            return;
        }

        // Perform payment (assuming a method like `makePayment` exists in CreditAccount)
        creditAccount.makePayment(amount);
        System.out.println("Credit payment of $" + amount + " sent to account " + recipientAccountNumber);
    }

    private void creditRecompenseProcess(double amount) {
        CreditAccount creditAccount = getLoggedAccount();
        if (creditAccount == null) {
            System.out.println("No logged-in credit account.");
            return;
        }

        if (amount <= 0 || amount > creditAccount.getCurrentDebt()) {
            System.out.println("Invalid recompense amount.");
            return;
        }

        creditAccount.recompense(amount);
        System.out.println("Credit recompense of " + amount + " processed. Remaining debt: " + creditAccount.getCurrentDebt());
    }

    protected CreditAccount getLoggedAccount() {
        return (CreditAccount) super.getLoggedAccount();
    }

    @Override
    public void setLoggedAccount(Account account) {
        super.setLoggedAccount(account);
    }

    public void getCreditRecompenseProcess(double amount) {
        creditRecompenseProcess(amount);
    }

    public void getCreditPaymentProcess(String recipientAccountNumber, double amount) {
        creditPaymentProcess(recipientAccountNumber, amount);
    }
}
