package Launcher;

import Accounts.Account;
import Bank.Bank;

public class AccountLauncher {
    private Account loggedAccount;
    private Bank assocBank;

    public boolean isLogged() {
        return loggedAccount != null;
    }

    public Account checkCredentials(String accountNumber, String pin) {
        if (assocBank == null) return null; // No associated bank

        Account acc = assocBank.getBankAccount(accountNumber);
            if (acc.ACCOUNTNUMBER.equals(accountNumber) && acc.getPin().equals(pin)) {
                return acc; // Credentials match

        }
        return null; // No match found
    }

    public void setLoggedAccount(Account account) {
        this.loggedAccount = account;
    }

    public void destroyLoggedSession() {
        this.loggedAccount = null;
    }

    protected Account getLoggedAccount() {
        return loggedAccount;
    }
}

