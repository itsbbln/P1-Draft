package Accounts;
import Bank.Bank;

public class SavingsAccount extends Account implements Deposit, Withdrawal {
    private double balance;

    // Constructor
    public SavingsAccount(Bank bank, String accountNumber, String ownerLName, String ownerFName, String ownerEmail, String pin, double balance) {
        super(bank, accountNumber, ownerLName, ownerFName, ownerEmail, pin);
        this.balance = balance;
    }

    // Get balance statement
    public String getAccountBalanceStatement() {
        return "Current Balance: $" + balance;
    }

    // Check if enough balance for withdrawal
    private boolean hasEnoughBalance(double amount) {
        return balance >= amount;
    }

    // Handle insufficient balance scenario
    private void insufficientBalance() {
        System.out.println("Error: Insufficient balance for this transaction.");
    }

    // Adjust balance (for deposits/withdrawals)
    private void adjustAccountBalance(double amount) {
        this.balance += amount;
    }

    // Implemented from abstract method in Account
    @Override
    public String toString() {
        return "Savings Account [Owner: " + getOwnerFullName() + "\nBalance: $" + balance + "]";
    }

    @Override
    public boolean deposit(double amount) {
        if (amount > 0) {
            adjustAccountBalance(amount);
            System.out.println("Deposited: $" + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
        return false;
    }

    @Override
    public boolean cashDeposit(double amount) {
        if (amount > 0) {
            adjustAccountBalance(amount);
            return true;
        }
        return false;
    }

    @Override
    public boolean withdraw(double amount) {
        if (hasEnoughBalance(amount)) {
            adjustAccountBalance(-amount);
            System.out.println("Withdrew: $" + amount);
        } else {
            insufficientBalance();
        }
        return false;
    }

    @Override
    public boolean withdrawal(double amount) {
        if (hasEnoughBalance(amount)) {
            adjustAccountBalance(-amount);
            return true;
        }
        return false;
    }

    @Override
    public void transferFunds(double amount) {

    }

    @Override
    public boolean transfer(Account account, double amount) throws IllegalAccountType {
        return false;
    }

    @Override
    public boolean transfer(Bank bank, Account account, double amount) throws IllegalAccountType {
        return false;
    }
}

