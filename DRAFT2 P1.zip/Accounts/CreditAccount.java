package Accounts;

import Bank.Bank;


public class CreditAccount extends Account implements Payment, FundTransfer, Recompense {
    private double creditLimit;
    private double currentDebt;

    // Constructor
    public CreditAccount(Bank bank, String accountNumber, String ownerLName, String ownerFName, String ownerEmail, String pin, double creditLimit) {
        super(bank, accountNumber, ownerLName, ownerFName, ownerEmail, pin);
        this.creditLimit = creditLimit;
        this.currentDebt = 0; // Initially no debt
    }

    // Get available credit
    public double getAvailableCredit() {
        return creditLimit - currentDebt;
    }

    // Check if transaction exceeds credit limit
    public boolean exceedsCreditLimit(double amount) {
        return (currentDebt + amount) > creditLimit;
    }

    // Adjust debt (for payments or fund transfers)
    public void adjustDebt(double amount) {
        this.currentDebt += amount;
    }

    // Implement Payment interface
    @Override
    public void makePayment(double amount) {
        if (amount > 0 && amount <= currentDebt) {
            adjustDebt(-amount); // Reduce debt
            System.out.println("Payment of $" + amount + " made. Remaining Debt: $" + currentDebt);
        } else {
            System.out.println("Invalid payment amount.");
        }
    }

    // Implement FundTransfer interface
    @Override
    public void transferFunds(double amount) {
        if (!exceedsCreditLimit(amount)) {
            adjustDebt(amount); // Increase debt
            System.out.println("Transferred $" + amount + ". New Debt: $" + currentDebt);
        } else {
            System.out.println("Error: Exceeds credit limit.");
        }
    }

    // Implemented from abstract method in Account
    @Override
    public String toString() {
        return "Credit Account [Owner: " + getOwnerFullName() +
                "\nCredit Limit: $" + creditLimit + ", Current Debt: $" + currentDebt + "]";
    }

    @Override
    public boolean transfer(Bank bank, Account account, double amount) throws IllegalAccountType {
        return false;
    }

    @Override
    public boolean transfer(Account account, double amount) throws IllegalAccountType {
        return false;
    }

    @Override
    public boolean pay(Account account, double amount) throws IllegalAccountType {
        return false;
    }

    @Override
    public boolean recompense(double amount) {
        return false;
    }

    public double getCurrentDebt() {
        return currentDebt;
    }
}
