package Accounts;

import Bank.Bank;
import java.util.ArrayList;

public abstract class Account implements FundTransfer {  // Added 'abstract'
    protected Bank BANK;
    public String ACCOUNTNUMBER;
    protected String OWNERFNAME;
    protected String OWNERLNAME;
    protected String OWNEREMAIL;
    protected String pin;
    protected ArrayList<Transaction> TRANSACTIONS; // Stores transactions

    // Constructor
    public Account(Bank bank, String accountNumber, String ownerFName, String ownerLName, String ownerEmail, String pin) {
        this.BANK = bank;
        this.ACCOUNTNUMBER = accountNumber;
        this.OWNERFNAME = ownerFName;
        this.OWNERLNAME = ownerLName;
        this.OWNEREMAIL = ownerEmail;
        this.pin = pin;
        this.TRANSACTIONS = new ArrayList<>();
    }

    // Get owner's full name
    public String getOwnerFullName() {
        return OWNERLNAME + ", " + OWNERLNAME;
    }

    // Add a new transaction
    public void addNewTransaction(String accountNum, Transaction type, String description) {
        TRANSACTIONS.add(type);
    }

    // Get transaction history
    public String getTransactionsInfo() {
        StringBuilder sb = new StringBuilder();
        for (Transaction t : TRANSACTIONS) {
            sb.append(t.toString()).append("\n");
        }
        return sb.toString();
    }

    // Get PIN
    public String getPin() {
        return pin;
    }

    // Abstract method (to be implemented by subclasses)
    @Override
    public String toString()
    {
        return null;
    }
}