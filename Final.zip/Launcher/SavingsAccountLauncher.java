package Launcher;

import Accounts.*;
import Bank.Bank;
import Bank.BankComparator;

public class SavingsAccountLauncher extends AccountLauncher {
    public void savingsAccountInit() {
        SavingsAccount account = getLoggedAccount();
        if (account == null) {
            System.out.println("\nError: No logged-in savings account.");
            return;
        }
        System.out.println("\nSavings Account operations initialized.");
    }

    private void depositProcess(double amount) {
        SavingsAccount account = getLoggedAccount();
        if (account == null) {
            System.out.println("\nNo logged-in savings account.");
            return;
        }

        if (amount <= 0) {
            System.out.println("\nInvalid deposit amount.");
            return;
        }

        account.cashDeposit(amount);
        System.out.println("\nDeposit successful. New balance: " + account.getAccountBalanceStatement());
    }

    private void withdrawProcess(double amount) {
        SavingsAccount account = getLoggedAccount();
        if (account == null) {
            System.out.println("\nNo logged-in savings account.");
            return;
        }

        if ((amount <= 0) || amount > Double.parseDouble(account.getAccountBalanceStatement().replace("$", ""))) {
            System.out.println("\nInvalid withdrawal amount.");
            return;
        }

        account.withdrawal(amount);
        System.out.println("\nWithdrawal successful. New balance: " + account.getAccountBalanceStatement());
    }

    private void fundTransferProcess(SavingsAccount recipient, double amount) {
        Account account = super.getLoggedAccount();

        // Ensure the logged-in account is a SavingsAccount
        if (!(account instanceof SavingsAccount loggedAccount)) {
            System.out.println("\nNo logged-in savings account.");
            return;
        }

        System.out.println("\nFund transfer initiated from: " + loggedAccount.getAccountNumber());

        // Retrieve the bank associated with the logged-in savings account
        Bank senderBank = loggedAccount.getBank();
        Bank recipientBank = recipient.getBank();

        if (senderBank == null || recipientBank == null) {
            System.out.println("\nError: Bank not found.");
            return;
        }

        // Use BankComparator to check if it's an internal or external transfer
        BankComparator bankComparator = new BankComparator();
        double processingFee = senderBank.getProcessingFee();
        double senderBalance = Double.parseDouble(loggedAccount.getAccountBalanceStatement().replace("$", ""));

        if (bankComparator.compare(senderBank, recipientBank) == 0) {
            // Internal Transfer (Same Bank, No Processing Fee)
            try {
                if (loggedAccount.transfer(recipient, amount)) {
                    System.out.println("\nFund transfer successful! (Internal Transfer)");
                } else {
                    System.out.println("\nFund transfer failed.");
                }
            } catch (IllegalAccountType e) {
                System.out.println("\nError: " + e.getMessage());
            }
        } else {
            // External Transfer (Different Bank, Processing Fee Applies)
            double totalAmount = amount + processingFee;

            if (senderBalance < totalAmount) {
                System.out.println("\nError: Insufficient balance for this transfer including processing fee.");
                return;
            }

            try {
                if (loggedAccount.transfer(recipientBank, recipient, amount)) {
                    System.out.println("\nFund transfer successful! (External Transfer with $" + processingFee + " processing fee applied)");
                } else {
                    System.out.println("\nFund transfer failed.");
                }
            } catch (IllegalAccountType e) {
                System.out.println("\nError: " + e.getMessage());
            }
        }
    }
    protected SavingsAccount getLoggedAccount() {
        Account account = super.getLoggedAccount();
        if (account instanceof SavingsAccount) {
            return (SavingsAccount) account;
        }
        return null;
    }

    // Getters
    public void getDepositProcess(double amount) {
        depositProcess(amount);
    }

    public void getWithdrawProcess(double amount) {
        withdrawProcess(amount);
    }

    @Override
    public void setLoggedSession(Account account) {
        super.setLoggedSession(account);
    }

    public void getFundTransferProcess(SavingsAccount recipient, double amount) {
        fundTransferProcess(recipient, amount);
    }
}
