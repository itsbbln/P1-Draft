package Accounts;

import Bank.Bank;
import java.util.ArrayList;

public abstract class Account implements FundTransfer {
    private Bank BANK;
    public String ACCOUNTNUMBER;
    private String OWNERFNAME;
    private String OWNERLNAME;
    private String OWNEREMAIL;
    private String pin;
    private ArrayList<Transaction> TRANSACTIONS; // Stores transactions

    // Constructor
    public Account(Bank bank, String accountNumber, String ownerFName, String ownerLName, String ownerEmail, String pin) {
        this.BANK = bank;
        this.ACCOUNTNUMBER = accountNumber;
        this.OWNERFNAME = ownerFName;
        this.OWNERLNAME = ownerLName;
        this.OWNEREMAIL = ownerEmail;
        this.pin = pin;
        this.TRANSACTIONS = new ArrayList<>();
    }

    // Get owner's full name
    public String getOwnerFullName() {
        return OWNERLNAME + ", " + OWNERFNAME;
    }

    // Add a new transaction
    public void addNewTransaction(String accountNum, Transaction.Transactions transactionType, String description) {
        TRANSACTIONS.add(new Transaction(accountNum, transactionType, description));
    }

    // Get transaction history
    public String getTransactionsInfo() {
        if (TRANSACTIONS.isEmpty()) {
            return "\nNo transactions available.";
        }

        StringBuilder sb = new StringBuilder("\n----- Transaction History -----\n");
        for (Transaction t : TRANSACTIONS) {
            sb.append(t.toString());
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return "\nAccount Number: " + ACCOUNTNUMBER +
                "\nOwner: " + getOwnerFullName() +
                "\nEmail: " + OWNEREMAIL +
                "\nBank: " + BANK.getName();
    }

    // Getters
    public String getPin() {
        return pin;
    }

    public String getAccountNumber() {
        return ACCOUNTNUMBER;
    }

    public Bank getBank() {
        return this.BANK;
    }

    public String getOwnerFName() {
        return this.OWNERFNAME;
    }

    public String getOwnerLName() {
        return this.OWNERLNAME;
    }

}