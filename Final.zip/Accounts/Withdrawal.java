package Accounts;

public interface Withdrawal {
    // Implementing Withdrawal interface
    boolean withdraw(double amount);

    /**
     * Withdraws an amount of money using a given medium.
     * @param amount Amount of money to be withdrawn from.
     */
    public boolean withdrawal(double amount);
}
