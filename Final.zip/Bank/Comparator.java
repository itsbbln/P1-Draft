package Bank;

public interface Comparator<B> {
    int compare(B b1, B b2);
}
