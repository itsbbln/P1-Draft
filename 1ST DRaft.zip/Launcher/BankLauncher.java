package Launcher;
import Bank.Bank;

import java.util.ArrayList;
import java.util.Comparator;


public class BankLauncher {
    private static ArrayList<Bank> BANKS = new ArrayList<>();
    private static Bank loggedBank = null;

    // Check if a user is logged in
    public boolean isLoggedIn() {
        return loggedBank != null;
    }

    // Bank login process
    public static boolean bankLogin(String name, String passcode) {
        for (Bank bank : BANKS) {
            if (bank.getName().equals(name) && bank.getPasscode().equals(passcode)) {
                loggedBank = bank;
                return true;
            }
        }
        return false; // Login failed
    }

    // Show all banks
    public void showBanks() {
        for (Bank bank : BANKS) {
            System.out.println(bank);
        }
    }

    // Create a new bank
    public static void createNewBank(String name, String passcode, double depositLimit, double withdrawLimit, double creditLimit, double processingFee) {
        int id = BANKS.size() + 1; // Assigning unique ID based on size
        Bank newBank = new Bank(id, name, passcode, depositLimit, withdrawLimit, creditLimit, processingFee);
        BANKS.add(newBank);
    }

    // Logout from the bank
    public void logout() {
        loggedBank = null;
    }

    // Get currently logged-in bank
    public Bank getLoggedBank() {
        return loggedBank;
    }

    // Sort banks using a comparator
    public void sortBanks(Comparator<Bank> comparator) {
        BANKS.sort(comparator);
    }

    // Get total number of banks
    public int bankSize() {
        return BANKS.size();
    }

    // Get a bank by name
    public static Bank getBankByName(String bankName) {
        for (Bank bank : BANKS) {
            if (bank.getName().equalsIgnoreCase(bankName)) {
                return bank;
            }
        }
        return null; // Return null if bank is not found
    }
}
