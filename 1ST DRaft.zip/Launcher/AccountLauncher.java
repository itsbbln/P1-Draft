package Launcher;

import Accounts.Account;
import Accounts.SavingsAccount;
import Accounts.CreditAccount;
import Bank.Bank;
import java.util.Scanner;

public class AccountLauncher {
    private Account loggedAccount;
    private Bank assocBank;

    public boolean isLogged() {
        return loggedAccount != null;
    }

    public Account checkCredentials(String accountNumber, String pin) {
        if (assocBank == null) return null; // No associated bank

        for (Account acc : assocBank.getBankAccount) {
            if (acc.getAccountNumber().equals(accountNumber) && acc.getPin().equals(pin)) {
                return acc; // Credentials match
            }
        }
        return null; // No match found
    }

    public void setLoggedAccount(Account account) {
        this.loggedAccount = account;
    }

    public void destroyLoggedSession() {
        this.loggedAccount = null;
    }

    public Account getLoggedAccount() {
        return loggedAccount;
    }
}

