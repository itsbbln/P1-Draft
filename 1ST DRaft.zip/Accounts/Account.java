package Accounts;
import Bank.Bank;

public abstract class Account {
    protected Bank bank;
    protected String accountNumber;
    protected String ownerName;
    protected String ownerEmail;

    public Account(Bank bank, String accountNumber, String ownerName, String ownerEmail) {
        this.bank = bank;
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.ownerEmail = ownerEmail;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public String getOwnerEmail() {
        return ownerEmail;
    }

    public Bank getBank() {
        return bank;
    }

    public abstract String toString();
}
