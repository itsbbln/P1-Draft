package Accounts;
import Bank.Bank;

public class CreditAccount extends Account implements Withdrawal, FundTransfer {
    private double balance;
    private double creditLimit;

    public CreditAccount(Bank bank, String accountNumber, String ownerName, String ownerEmail, String creditLimit) {
        super(bank, accountNumber, ownerName, ownerEmail);
        this.balance = 0;  // Credit accounts start with 0 balance.
        this.creditLimit = Double.parseDouble(creditLimit);
    }

    public double getBalance() {
        return balance;
    }

    public double getCreditLimit() {
        return creditLimit;
    }

    @Override
    public boolean withdrawal(double amount) {
        if (amount > 0 && (balance + amount) <= creditLimit) {
            balance += amount;  // Since it's credit, "withdrawing" increases debt.
            return true;
        }
        return false;
    }

    @Override
    public boolean transfer(Bank bank, Account account, double amount) throws IllegalAccountType {
        double totalAmount = amount + bank.getProcessingFee();
        if (withdrawal(totalAmount)) {
            if (account instanceof SavingsAccount) {
                ((SavingsAccount) account).cashDeposit(amount);
                return true;
            } else {
                throw new IllegalAccountType("Cannot transfer to an incompatible account type.");
            }
        }
        return false;
    }

    @Override
    public boolean transfer(Account account, double amount) throws IllegalAccountType {
        if (withdrawal(amount)) {
            if (account instanceof SavingsAccount) {
                ((SavingsAccount) account).cashDeposit(amount);
                return true;
            } else {
                throw new IllegalAccountType("Cannot transfer to an incompatible account type.");
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "Credit Account: " + accountNumber + " | Balance: " + balance + " | Credit Limit: " + creditLimit;
    }
}
