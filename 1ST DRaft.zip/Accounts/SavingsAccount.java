package Accounts;
import Bank.Bank;

public class SavingsAccount extends Account implements Withdrawal, Deposit, FundTransfer {
    private double balance;

    public SavingsAccount(Bank bank, String accountNumber, String ownerName, String ownerEmail, double balance) {
        super(bank, accountNumber, ownerName, ownerEmail);
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    @Override
    public boolean cashDeposit(double amount) {  // Matches Deposit interface
        if (amount > 0) {
            balance += amount;
            return true;
        }
        return false;
    }

    @Override
    public boolean withdrawal(double amount) {  // Matches Withdrawal interface
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;
        }
        return false;
    }

    @Override
    public boolean transfer(Bank bank, Account account, double amount) throws IllegalAccountType { // Matches FundTransfer interface
        double totalAmount = amount + bank.getProcessingFee();
        if (withdrawal(totalAmount)) {
            if (account instanceof SavingsAccount) {
                ((SavingsAccount) account).cashDeposit(amount);
                return true;
            } else {
                throw new IllegalAccountType("Cannot transfer to an incompatible account type.");
            }
        }
        return false;
    }

    @Override
    public boolean transfer(Account account, double amount) throws IllegalAccountType { // Matches FundTransfer interface
        if (withdrawal(amount)) {
            if (account instanceof SavingsAccount) {
                ((SavingsAccount) account).cashDeposit(amount);
                return true;
            } else {
                throw new IllegalAccountType("Cannot transfer to an incompatible account type.");
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "Savings Account: " + accountNumber + " | Balance: " + balance;
    }
}

