package Bank;
import Accounts.Account;
import Accounts.CreditAccount;
import Accounts.SavingsAccount;

import java.util.ArrayList;

public class Bank {
    public Account[] getBankAccount;
    private int ID;
    private String name, passcode;
    private double DEPOSITLIMIT, WITHDRAWLIMIT, CREDITLIMIT;
    private double processingFee;
    private ArrayList<Account> BANKACCOUNTS;

    // Constructor
    public Bank(int ID, String name, String passcode, double depositLimit, double withdrawLimit, double creditLimit, double processingFee) {
        this.ID = ID;
        this.name = name;
        this.passcode = passcode;
        this.DEPOSITLIMIT = depositLimit;
        this.WITHDRAWLIMIT = withdrawLimit;
        this.CREDITLIMIT = creditLimit;
        this.processingFee = processingFee;
        this.BANKACCOUNTS = new ArrayList<>();
    }

    //Overloaded Constructor
    public Bank(int ID, String name, String passcode) {
        this(ID, name, passcode, 0, 0, 0, 0);
    }

    public Bank(String myBank) {
    }

    public void showAccountsByType(Class<?> type) {
        for (Account acc : BANKACCOUNTS) {
            if (type.isInstance(acc)) {
                System.out.println(acc);
            }
        }
    }

    // Retrieve an account by number
    public Account getBankAccount(Bank bank, String accountNum) {
        for (Account acc : bank.BANKACCOUNTS) {
            if (acc.getAccountNumber().equals(accountNum)) {
                return acc;
            }
        }
        return null; // Account not found
    }

    // Create new Savings Account
    public SavingsAccount createNewSavingsAccount(String accountNumber, String ownerName, String ownerEmail, double balance) {
        SavingsAccount newAccount = new SavingsAccount(this, accountNumber, ownerName, ownerEmail, balance);
        BANKACCOUNTS.add(newAccount);
        return newAccount;
    }

    // Create new Credit Account
    public CreditAccount createNewCreditAccount(String accountNumber, String ownerName, String ownerEmail, String pin) {
        CreditAccount newAccount = new CreditAccount(this, accountNumber, ownerName, ownerEmail, pin);
        BANKACCOUNTS.add(newAccount);
        return newAccount;
    }

    // Add an existing account
    public void addNewAccount(Account account) {
        BANKACCOUNTS.add(account);
    }

    // Check if an account number exists
    public boolean accountExists(String accountNum) {
        for (Account acc : BANKACCOUNTS) {
            if (acc.getAccountNumber().equals(accountNum)) {
                return true;
            }
        }
        return false;
    }

    // Getter Methods
    public int getID(){
        return ID;
    }

    public String getName() {
        return name;
    }

    public String getPasscode() {
        return passcode;
    }

    public double getDepositLimit() {
        return DEPOSITLIMIT;
    }

    public double getWithdrawLimit() {
        return WITHDRAWLIMIT;
    }

    public double getCreditLimit() {
        return CREDITLIMIT;
    }

    public double getProcessingFee() {
        return processingFee;
    }

    public String toString() {
        return "Bank Name: " + name + " | ID: " + ID;
    }
}
