package Bank;

public interface Comparator {
}
