package Bank;
import java.util.Comparator;

public class BankComparator implements Comparator<Bank> {
    private Bank b1;
    private Bank b2;

    // Compare banks by ID
    public int compare(Bank b1, Bank b2) {
        return Integer.compare(b1.getID(), b2.getID());
    }
}
