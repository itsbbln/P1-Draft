package Accounts;
import Bank.Bank;

public class SavingsAccount extends Account implements Deposit, Withdrawal {
    private double balance;

    // Constructor
    public SavingsAccount(Bank bank, String accountNumber, String ownerFName, String ownerLName, String ownerEmail, String pin, double balance) {
        super(bank, accountNumber, ownerFName, ownerLName, ownerEmail, pin);
        this.balance = balance;
    }

    // Get balance statement
    public String getAccountBalanceStatement() {
        return String.valueOf(balance);
    }

    // Check if enough balance for withdrawal
    private boolean hasEnoughBalance(double amount) {
        return balance >= amount;
    }

    // Handle insufficient balance scenario
    private void insufficientBalance() {
        System.out.println("\nError: Insufficient balance for this transaction.");
    }

    // Adjust balance (for deposits/withdrawals)
    private void adjustAccountBalance(double amount) {
        this.balance += amount;
    }

    public boolean deposit(double amount) {
        if (amount > 0) {
            adjustAccountBalance(amount);

            Transaction transaction = new Transaction(getAccountNumber(), Transaction.Transactions.Deposit, "Deposited $" + amount);
            System.out.println(transaction);
            addNewTransaction(getAccountNumber(), Transaction.Transactions.Deposit, transaction.toString());
            return true;
        } else {
            System.out.println("\nInvalid deposit amount.");
            return false;
        }
    }

    @Override
    public boolean cashDeposit(double amount) {
        return deposit(amount);
    }

    public boolean withdraw(double amount) {
        if (hasEnoughBalance(amount)) {
            adjustAccountBalance(-amount);
            Transaction transaction = new Transaction(getAccountNumber(), Transaction.Transactions.Withdraw, "Withdraw: $" + amount);
            System.out.println(transaction);
            addNewTransaction(getAccountNumber(), Transaction.Transactions.Withdraw, transaction.toString());
            return true;
        } else {
            insufficientBalance();
        }
        return false;
    }

    @Override
    public boolean withdrawal(double amount) {
        return withdraw(amount);
    }

    public void transferFunds(double amount) {
        if (hasEnoughBalance(amount)) {
            adjustAccountBalance(-amount);
            Transaction transaction = new Transaction(getAccountNumber(), Transaction.Transactions.FundTransfer, "Transferred funds: $" + amount);
            System.out.println(transaction);
            addNewTransaction(getAccountNumber(), Transaction.Transactions.FundTransfer, transaction.toString());
        } else {
            insufficientBalance();
        }
    }

    @Override
    public boolean transfer(Account recipient, double amount) throws IllegalAccountType {
        if (!(recipient instanceof SavingsAccount)) {
            throw new IllegalAccountType("\nInvalid recipient. Only savings accounts are allowed.");
        }

        if (hasEnoughBalance(amount)) {
            transferFunds(amount);
            ((SavingsAccount) recipient).deposit(amount);
            // Create a transaction record for the sender
            Transaction senderTransaction = new Transaction(getAccountNumber(), Transaction.Transactions.FundTransfer, "Transferred $" + amount + " to " + recipient.getAccountNumber());
            System.out.println(senderTransaction);
            addNewTransaction(getAccountNumber(), Transaction.Transactions.FundTransfer, senderTransaction.toString());
            // Create a transaction record for the recipient
            Transaction recipientTransaction = new Transaction(recipient.getAccountNumber(), Transaction.Transactions.FundTransfer, "Received $" + amount + " from " + getAccountNumber());
            recipient.addNewTransaction(recipient.getAccountNumber(), Transaction.Transactions.FundTransfer, recipientTransaction.toString());

            System.out.println("Transfer successful: $" + amount + " sent to " + recipient);
            return true;
        }
        System.out.println("\nTransfer failed.");
        return false;
    }

    @Override
    public boolean transfer(Bank bank, Account account, double amount) throws IllegalAccountType {
        if (!(account instanceof SavingsAccount)) {
            throw new IllegalAccountType("\nInvalid recipient. Only savings accounts are allowed.");
        }

        double totalAmount = amount + bank.getProcessingFee();

        if (!hasEnoughBalance(totalAmount)) {
            insufficientBalance();
            return false;
        }
        transferFunds(totalAmount);
        adjustAccountBalance(-totalAmount); // Withdraw from source account (with processing fee)
        ((SavingsAccount) account).deposit(amount); // Deposit to recipient account

        // Create a transaction record for the sender
        Transaction senderTransaction = new Transaction(getAccountNumber(), Transaction.Transactions.FundTransfer, "Transferred $" + amount + " to [" + bank.getName() + " - " + account.getAccountNumber() + "] with $" + bank.getProcessingFee() + " fee.");
        System.out.println(senderTransaction);
        addNewTransaction(getAccountNumber(), Transaction.Transactions.FundTransfer, senderTransaction.toString());

        // Create a transaction record for the recipient
        Transaction recipientTransaction = new Transaction(account.getAccountNumber(), Transaction.Transactions.FundTransfer, "Received $" + amount + " from " + getAccountNumber() + ", " + getBank().getID());
        account.addNewTransaction(account.getAccountNumber(), Transaction.Transactions.FundTransfer, recipientTransaction.toString());

        System.out.println("\nInter-bank transfer successful: $" + amount + " sent to " + account);
        return true;
    }

    public String toString(String accountNum, Transaction type, String description) {
        return "Transaction: " + type + "\nAccount: " + accountNum + "\nDescription: " + description;
    }
}

