package Accounts;

import Bank.Bank;

public class CreditAccount extends Account implements Payment, Recompense {
    private double loan;

    // Constructor
    public CreditAccount(Bank bank, String accountNumber, String ownerFName, String ownerLName, String ownerEmail, String pin, double creditLimit) {
        super(bank, accountNumber, ownerFName, ownerLName, ownerEmail, pin);
        this.loan = 0; // Initially no loan
    }

    public String getLoanStatement() {
        return """
               
               ----- Loan Statement -----
               
               Account: """ + getAccountNumber() + "\n" +
                "Owner: " + getOwnerFullName() + "\n" +
                "Current Loan: $" + loan;
    }
    private boolean canCredit(double amountAdjustment) {
        return (loan + amountAdjustment) >= 0;
    }

    private void adjustLoanAmount(double amountAdjustment) {
        if (canCredit(amountAdjustment)) {
            this.loan += amountAdjustment;
        } else {
            System.out.println("\nError: Exceeds credit limit.");
        }
    }

    public boolean requestLoan(double amount, double creditLimit) {
        if (amount > 0 && (loan + amount) <= creditLimit) {
            adjustLoanAmount(amount);
            String description = "Request Loan of $" + amount;
            addNewTransaction(getAccountNumber(), Transaction.Transactions.Loan, description);
            System.out.println(description);
            return true;
        } else {
            System.out.println("\nError: Loan request exceeds credit limit.");
            return false;
        }
    }

    // Implemented from abstract method in Account
    @Override
    public String toString() {
        return "\nAccount Number: " + getAccountNumber() +
                "\nOwner: " + getOwnerFullName();
    }

    // Implement Payment interface
    public void makePayment(double amount) {
        if (amount > 0 && amount <= loan) {
            adjustLoanAmount(-amount); // Reduce debt
            String description = "\nPayment of $" + amount + " made. Remaining Debt: $" + loan;
            addNewTransaction(getAccountNumber(), Transaction.Transactions.Payment, description);
            System.out.println(description);
        } else {
            System.out.println("\nInvalid payment amount.");
        }
    }

    public void transferFunds(double amount) {
        System.out.println("\nError: Credit accounts cannot transfer funds directly.");
    }

    @Override
    public boolean transfer(Bank bank, Account account, double amount) {
        return false;
    }

    @Override
    public boolean transfer(Account account, double amount) {
        return false;
    }

    public String toString(String accountNum, Transaction type, String description) {
        return "";
    }

    @Override
    public boolean pay(Account account, double amount) throws IllegalAccountType {
        if (!(account instanceof SavingsAccount)) {
            throw new IllegalAccountType("\nCredit accounts can only pay to Savings Accounts.");
        }

        if (amount <= 0 || amount > loan) {
            System.out.println("\nError: Payment amount exceeds current debt.");
            return false;
        }

        adjustLoanAmount(-amount); // Reduce debt
        ((SavingsAccount) account).deposit(amount); // Increase recipient balance

        String description = "Paid $" + amount + " to Savings Account: " + account.getAccountNumber();
        addNewTransaction(getAccountNumber(), Transaction.Transactions.Payment, description);
        System.out.println(description);

        return true;
    }

    @Override
    public boolean recompense(double amount) {
        if (amount > 0 && amount <= loan) {
            adjustLoanAmount(-amount); // Reduce debt
            String description = "Recompense of $" + amount + " applied. New Debt: $" + loan;
            addNewTransaction(getAccountNumber(), Transaction.Transactions.Recompense, description);
            System.out.println(description);
            return true;
        } else {
            System.out.println("\nRecompense failed. Amount exceeds current debt.");
            return false;
        }
    }

    public double getCurrentDebt() {
        return loan;
    }

}
