package Main;
import java.util.ArrayList;
import java.util.Scanner;

import Accounts.CreditAccount;
import Bank.Bank;
import Bank.BankComparator;
import Bank.BankCredentialsComparator;
import Launcher.AccountLauncher;
import Launcher.BankLauncher;
import Accounts.Account;
import Accounts.SavingsAccount;
import Launcher.CreditAccountLauncher;
import Launcher.SavingsAccountLauncher;

public class Main
{

    private static final Scanner input = new Scanner(System.in);
    /**
     * Option field used when selection options during menu prompts. Do not create a different
     * option variable in menus. Just use this instead. <br>
     * As to how to utilize Field objects properly, refer to the following:
     * 
     * @see #prompt(String, boolean)
     * @see #setOption() How Field objects are used.
     */
    public static Field<Integer, Integer> option = new Field<Integer, Integer>("Option",
            Integer.class, -1, new Field.IntegerFieldValidator());

    public static void main(String[] args)
    {
        while (true)
        {
            showMenuHeader("Main Menu");
            showMenu(1);
            setOption();
            // Account Option
            if (getOption() == 1)
            {
                AccountLauncher accountLauncher = new AccountLauncher();
                
                while (true) {
                    // READ ME: Refer to this code block on how one should properly utilize
                    // showMenuHeader(), showMenu(),
                    // setOption(), and getOption() methods...
                    showMenuHeader("Account Login Menu");
                    showMenu(2, 1);
                    setOption();
                    // TODO: Complete this portion

                    if (getOption() == 1) {

                        // Prompt for account login details
                        Field<String, String> bankNameField = new Field<String, String>("Enter Bank Name: ", String.class, null, new Field.StringFieldValidator());
                        bankNameField.setFieldValue("Enter Bank Name: ");
                        String bankName = bankNameField.getFieldValue();
                        Bank selectedBank = accountLauncher.getSelectBank(bankName);

                        if (selectedBank == null) {
                            continue;
                        }
                        boolean hasAccounts = false;
                        for (Account acc : selectedBank.getBankAccounts()) {
                            if (Bank.accountExist(selectedBank, acc.getAccountNumber())) {
                                hasAccounts = true;
                                break;
                            }
                        }
                        if (!hasAccounts) {
                            System.out.println("\nNo accounts exist in this bank.");
                            continue; // Skip further execution and return to the main loop
                        }

                        while (true) {
                            showMenuHeader("Select Account Type");
                            showMenu(33, 1);
                            setOption();

                            if (getOption() == 3) {
                                System.out.println("\nGo back to login menu.");
                                break;
                            }

                            if (accountLauncher.getIsLogged()) {
                                System.out.println("\nYou are already logged in.");
                                continue;
                            }

                            Field<String, Integer> accountNumberField = new Field<String, Integer>("Enter account number: ", String.class, 10, new Field.StringFieldLengthValidator());
                            accountNumberField.setFieldValue("Enter Account Number (must be 10 characters - minimum): ");
                            String accountNumber = accountNumberField.getFieldValue();

                            Field<String, Integer> pinField = new Field<String, Integer>("Enter PIN: ", String.class, 4, new Field.StringFieldLengthValidator());
                            pinField.setFieldValue("Enter PIN: ");
                            String pin = pinField.getFieldValue();

                            // Validate that the PIN is exactly 4 characters long
                            if (pin.length() != 4) {
                                System.out.println("\nInvalid PIN! It must be exactly 4 digits.");
                                continue; // Prompt again if the PIN is not valid
                            }

                            // Check if the account exists before proceeding
                            if (!Bank.accountExist(selectedBank, accountNumber)) {
                                System.out.println("\nNo accounts exist.");
                                continue;
                            }

                            accountLauncher.accountLogin(accountNumber, pin);
                            Account selectedAccount = accountLauncher.fetchLoggedAccount();


                            if (getOption() == 1) {

                                if (!(selectedAccount instanceof CreditAccount account)) {
                                    System.out.println("\nNo credit account found.");
                                    continue;
                                }

                                CreditAccountLauncher creditLauncher = new CreditAccountLauncher();
                                creditLauncher.setLoggedSession(account);
                                creditLauncher.creditAccountInit();
                                System.out.println("\nSuccessfully logged into Credit Account: " + accountNumber);

                                while (true) {
                                    showMenuHeader("Credit Account Menu");
                                    showMenu(41, 1);
                                    setOption();

                                    if (getOption() == 1) {
                                        System.out.println(account.getLoanStatement());

                                    } else if (getOption() == 2) { // Pay
                                        Field<Double, Double> paymentField = new Field<Double, Double>("Enter amount to pay: ", Double.class, 0.0, new Field.DoubleFieldValidator());
                                        paymentField.setFieldValue("Enter amount to pay: ");
                                        double amount = paymentField.getFieldValue();

                                        Field<String, Integer> recipientField = new Field<String, Integer>("Enter recipient account number: ", String.class, 10, new Field.StringFieldLengthValidator());
                                        recipientField.setFieldValue("Enter recipient account number (must be 10 characters - minimum): ");
                                        String recipientAccountNumber = recipientField.getFieldValue();

                                        // Ensure the recipient is a SavingsAccount
                                        Account recipient = selectedBank.getBankAccount(recipientAccountNumber);
                                        if (!(recipient instanceof SavingsAccount)) {
                                            System.out.println("\nError: You can only send payments to a Savings Account.");
                                            continue;
                                        }
                                        creditLauncher.getCreditPaymentProcess(recipientAccountNumber, amount);

                                    } else if (getOption() == 3) { // Recompense
                                        Field<Double, Double> recompenseField = new Field<Double, Double>("Enter recompense amount: ", Double.class, 0.0, new Field.DoubleFieldValidator());
                                        recompenseField.setFieldValue("Enter recompense amount: ");
                                        double amount = recompenseField.getFieldValue();
                                        creditLauncher.getCreditRecompenseProcess(amount);

                                    } else if (getOption() == 4) { // Add Credit (Loan)
                                        Field<Double, Double> loanField = new Field<Double, Double>("Enter loan amount: ", Double.class, 0.0, new Field.DoubleFieldValidator());
                                        loanField.setFieldValue("Enter loan amount: ");
                                        double loanAmount = loanField.getFieldValue();
                                        double creditLimit = selectedBank.getCreditLimit();

                                        boolean success = account.requestLoan(loanAmount, creditLimit);
                                        if (success) {
                                            System.out.println("\nLoan successfully granted. New loan balance: $" + account.getCurrentDebt());
                                        }

                                    } else if (getOption() == 5) { // Show Transactions
                                        System.out.println(selectedAccount.getTransactionsInfo());

                                    } else if (getOption() == 6) {
                                        System.out.println("\nLogging out of credit account.");
                                        accountLauncher.getDestroyLoggedSession();
                                        break;
                                    }
                                }
                            }
                            else if (getOption() == 2) { // Savings Account
                                if (!(selectedAccount instanceof SavingsAccount account)) {
                                    System.out.println("\nNo savings account found.");
                                    continue;
                                }

                                SavingsAccountLauncher savingsLauncher = new SavingsAccountLauncher();
                                savingsLauncher.setLoggedSession(account);
                                savingsLauncher.savingsAccountInit();
                                System.out.println("\nSuccessfully logged into Savings Account: " + accountNumber);

                                while (true) {
                                    showMenuHeader("Savings Account Menu");
                                    showMenu(51, 1);
                                    setOption();

                                    if (getOption() == 1) {
                                        System.out.println("\nYour Current Balance: " + account.getAccountBalanceStatement());

                                    } else if (getOption() == 2) {
                                        double depositLimit = selectedBank.getDepositLimit();
                                        Field<Double, Double> depositField = new Field<Double, Double>("Enter deposit amount: ", Double.class, 0.0, new Field.DoubleFieldValidator());
                                        depositField.setFieldValue("Enter deposit amount: ");
                                        double amount = depositField.getFieldValue();

                                        if (amount > depositLimit) {
                                            System.out.println("\nDeposit failed! Amount exceeds the deposit limit of $" + depositLimit);
                                        } else {
                                            savingsLauncher.getDepositProcess(amount);
                                        }

                                    } else if (getOption() == 3) {
                                        double withdrawLimit = selectedBank.getWithdrawLimit();
                                        Field<Double, Double> withdrawField = new Field<Double, Double>("Enter withdrawal amount: ", Double.class, 0.0, new Field.DoubleFieldValidator());
                                        withdrawField.setFieldValue("Enter withdrawal amount: ");
                                        double amount = withdrawField.getFieldValue();

                                        if (amount > withdrawLimit) {
                                            System.out.println("\nWithdrawal failed! Amount exceeds the withdrawal limit of $" + withdrawLimit);
                                        } else {
                                            savingsLauncher.getWithdrawProcess(amount);
                                        }

                                    } else if (getOption() == 4) {  // Fund Transfer
                                        Field<String, Integer> recipientField = new Field<String, Integer>("Enter recipient account number: ", String.class, 10, new Field.StringFieldLengthValidator());
                                        recipientField.setFieldValue("Enter recipient account number (must be 10 characters - minimum): ");
                                        String recipientNumber = recipientField.getFieldValue();

                                        Field<Double, Double> transferField = new Field<Double, Double>("Enter transfer amount: ", Double.class, 0.0, new Field.DoubleFieldValidator());
                                        transferField.setFieldValue("Enter transfer amount: ");
                                        double amount = transferField.getFieldValue();

                                        SavingsAccount recipient = null;

                                        // Search for the recipient across all banks
                                        for (Bank bank : accountLauncher.getAllBanks()) {
                                            Account acc = bank.getBankAccount(recipientNumber);
                                            if (acc instanceof SavingsAccount) {
                                                recipient = (SavingsAccount) acc;
                                                break;
                                            }
                                        }

                                        if (recipient == null) {
                                            System.out.println("\nError: Recipient account not found.");
                                        } else {
                                            savingsLauncher.getFundTransferProcess(recipient, amount);
                                        }

                                    } else if (getOption() == 5) {
                                        System.out.println(selectedAccount.getTransactionsInfo());
                                    }
                                    else if (getOption() == 6) {
                                        System.out.println("\nLogging out of savings account");
                                        accountLauncher.getDestroyLoggedSession();
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else if (getOption() == 2) {
                        break;
                    }
                }
            }
            // Bank Option
            else if (getOption() == 2)
            {
                // TODO: Complete Bank option
                while (true) {
                    showMenuHeader("Bank Login Menu");
                    showMenu(3, 1);
                    setOption();

                    if (getOption() == 1) {
                        // Prompt for bank login details
                        Field<String, String> bankNameField = new Field<String, String>("Enter bank name to login: ", String.class, null, new Field.StringFieldValidator());
                        bankNameField.setFieldValue("Enter bank name to login: ");
                        String bankName = bankNameField.getFieldValue();

                        Field<String, Integer> passcodeField = new Field<String, Integer>("Enter Passcode (must be 10 characters minimum): ", String.class, 10, new Field.StringFieldLengthValidator());
                        passcodeField.setFieldValue("Enter Passcode (must be 10 characters - minimum): ");
                        String passcode = passcodeField.getFieldValue();

                        if (BankLauncher.isLoggedIn()) {
                            System.out.println("\nYou are already logged in.");
                            continue;
                        }

                        if (!BankLauncher.bankLogin(bankName, passcode)) {
                            System.out.println("\nNo bank with that name or passcode exists!");
                            continue;
                        }

                        AccountLauncher accountLauncher = new AccountLauncher();
                        Bank selectedBank = accountLauncher.getSelectBank(bankName);
                        if (selectedBank == null) {
                            continue;
                        }

                        BankLauncher.LogSession(selectedBank);
                        BankLauncher.bankInit();

                        while (true) {
                            showMenuHeader("Bank Menu");
                            showMenu(31, 1);
                            setOption();

                            if (getOption() == 1) {
                                while (true) {
                                    showMenuHeader("Select Account Type to Display");
                                    showMenu(32, 1);
                                    setOption();

                                    if (getOption() == 1) {
                                        System.out.println("\n--- Credit Accounts in " + bankName + " ---");
                                        BankLauncher.displayAccounts(CreditAccount.class);

                                    } else if (getOption() == 2) {
                                        System.out.println("\n--- Savings Accounts in " + bankName + " ---");
                                        BankLauncher.displayAccounts(SavingsAccount.class);

                                    } else if (getOption() == 3) {
                                        System.out.println("\n--- All Accounts in " + bankName + " ---");
                                        BankLauncher.displayAccounts(Account.class);

                                    } else if (getOption() == 4) {
                                        break; // Go back to Bank Menu
                                    }
                                }
                            }
                            else if (getOption() == 2) {
                                while (true) {
                                    showMenuHeader("Create New Account");
                                    showMenu(33, 1);
                                    setOption();

                                    if (getOption() == 3) {
                                        break; // Go back to bank menu
                                    }

                                    // Create new account
                                    Field<String, Integer> accountNumberField = new Field<String, Integer>("Account Number", String.class, 10, new Field.StringFieldLengthValidator());
                                    accountNumberField.setFieldValue("Enter Account Number (must be 10 characters - minimum): ");
                                    String newAccountNumber = accountNumberField.getFieldValue();

                                    if (BankLauncher.findAccount(newAccountNumber) != null) {
                                        System.out.println("\nAccount creation failed! Account number already exists.");
                                        continue;
                                    }

                                    Field<String, String> ownerLNameField = new Field<String, String>("Last Name: ", String.class, null, new Field.StringFieldValidator());
                                    ownerLNameField.setFieldValue("Enter Last Name: ");
                                    String ownerLName = ownerLNameField.getFieldValue();

                                    Field<String, String> ownerFNameField = new Field<String, String>("First Name: ", String.class, null, new Field.StringFieldValidator());
                                    ownerFNameField.setFieldValue("Enter First Name: ");
                                    String ownerFName = ownerFNameField.getFieldValue();

                                    Field<String, String> ownerEmailField = new Field<String, String>("Enter Email: ", String.class, null, new Field.StringFieldValidator());
                                    ownerEmailField.setFieldValue("Enter Email: ");
                                    String ownerEmail = ownerEmailField.getFieldValue();

                                    Field<String, Integer> pinField = new Field<String, Integer>("Enter PIN: ", String.class, 4, new Field.StringFieldLengthValidator());
                                    pinField.setFieldValue("Enter PIN: ");
                                    String pin = pinField.getFieldValue();

                                    // Use the comparator to check for duplicate credentials
                                    BankCredentialsComparator comparator = new BankCredentialsComparator();

                                    boolean isDuplicate = false;

                                    // Loop through all accounts in the selected bank
                                    for (Account account : selectedBank.getBankAccounts()) {
                                        // Check for duplicate credentials
                                        if (comparator.isDuplicate(account, ownerLName, ownerFName, ownerEmail, pin)) {
                                            isDuplicate = true;
                                            break;
                                        }
                                    }

                                    if (isDuplicate) {
                                        System.out.println("\nAccount creation failed! Duplicate credentials.");
                                        continue;
                                    }

                                    if (getOption() == 1) {
                                        double creditLimit = selectedBank.getCreditLimit();
                                        if (Bank.accountExist(selectedBank, newAccountNumber)) {
                                            System.out.println("\nAccount creation failed! Account number already exists.");
                                        }else {
                                            BankLauncher.newAccount("credit", newAccountNumber, ownerFName, ownerLName, ownerEmail, pin, creditLimit);
                                        }

                                    } else if (getOption() == 2) {

                                        Field<Double, Double> initialDepositField = new Field<Double, Double>("Initial Deposit", Double.class, 0.0, new Field.DoubleFieldValidator());
                                        initialDepositField.setFieldValue("Enter Initial Deposit: ");
                                        double initialDeposit = initialDepositField.getFieldValue();

                                        if (Bank.accountExist(selectedBank, newAccountNumber)) {
                                            System.out.println("\nAccount creation failed! Account number already exists.");
                                        }else {
                                            BankLauncher.newAccount("savings", newAccountNumber, ownerFName, ownerLName, ownerEmail, pin, initialDeposit);
                                        }
                                    }else {
                                        System.out.println("\nInvalid account type!");
                                    }
                                    // Sort and display all accounts after creation
                                    ArrayList<Account> accounts = selectedBank.getBankAccounts(); // Get all accounts from the selected bank
                                    comparator.sortAccounts(accounts);
                                    // Optionally, you can call createNewAccount to display all accounts after creation
                                    System.out.println("\n----- Current Accounts in " + selectedBank.getName() + " -----");
                                    for (Account acc : accounts) {
                                        System.out.println(acc);
                                    }
                                }
                            }
                            else if (getOption() == 3){
                                BankLauncher.logout();
                                break;
                            }
                            else{
                                System.out.println("\nInvalid bank name or passcode!");
                            }
                        }
                    }
                    else if (getOption() == 2) {
                        break; // Go back to Main Menu
                    }
                }
            }
            // Create New Bank
            else if (getOption() == 3)
            {
                // TODO: Complete this portion...
                System.out.println("\n----- Available Banks -----");
                BankLauncher.showBanksMenu();

                // Ensure Bank Name is not empty
                Field<String, String> bankName = new Field<String, String>("Bank Name", String.class, "", new Field.StringFieldValidator());
                bankName.setFieldValue("\nEnter Bank Name: ");
                String name = bankName.getFieldValue();

                // Use BankComparator to check if the bank name already exists
                Bank tempBank = new Bank(0, name, "", 0, 0, 0, 0);
                BankComparator comparator = new BankComparator();

                boolean exists = BankLauncher.getBank(comparator, tempBank) != null; // Check if bank exists

                if (exists) {
                    System.out.println("\nBank already exists. Please enter a different bank name.");
                } else {
                    Field<String, Integer> passcodeField = new Field<String, Integer>("Passcode", String.class, 10, new Field.StringFieldLengthValidator());
                    passcodeField.setFieldValue("Enter Passcode (must be 10 characters - minimum): ");
                    String passcode = passcodeField.getFieldValue();

                    // Fields for Deposit, Withdraw, Credit, and Processing Fee (Must be positive)
                    Field<Double, Double> depositField = new Field<Double, Double>("Deposit Limit", Double.class, 0.0, new Field.DoubleFieldValidator());
                    depositField.setFieldValue("Enter Deposit Limit: ");
                    double depositLimit = depositField.getFieldValue();
                    
                    Field<Double, Double> withdrawField = new Field<Double, Double>("Withdraw Limit", Double.class, 0.0, new Field.DoubleFieldValidator());
                    withdrawField.setFieldValue("Enter Withdraw Limit: ");
                    double withdrawLimit = withdrawField.getFieldValue();
                    
                    Field<Double, Double> creditField = new Field<Double, Double>("Credit Limit", Double.class, 0.0, new Field.DoubleFieldValidator());
                    creditField.setFieldValue("Enter Credit Limit: ");
                    double creditLimit = creditField.getFieldValue();
                    
                    Field<Double, Double> feeField = new Field<Double, Double>("Processing Fee", Double.class, 0.0, new Field.DoubleFieldValidator());
                    feeField.setFieldValue("Enter Processing Fee: ");
                    double processingFee = feeField.getFieldValue();

                    BankLauncher.createNewBank(name, passcode, depositLimit, withdrawLimit, creditLimit, processingFee);
                    System.out.println("\nBank created successfully!");
                    System.out.println("\nTotal Banks: " + BankLauncher.bankSize());
                }
            }
            else if (getOption() == 4)
            {
                System.out.println("Exiting. Thank you for banking!");
                break;
            }
            else
            {
                System.out.println("Invalid option!");
            }
        }
    }

    /**
     * Show menu based on index given. <br>
     * Refer to Menu enum for more info about menu indexes. <br>
     * Use this method if you want a single menu option every line.
     * 
     * @param menuIdx Main.Menu index to be shown
     */
    public static void showMenu(int menuIdx)
    {
        showMenu(menuIdx, 1);
    }

    /**
     * Show menu based on index given. <br>
     * Refer to Menu enum for more info about menu indexes.
     * 
     * @param menuIdx Main.Menu index to be shown
     * @param inlineTexts Number of menu options in a single line. Set to 1 if you only want a
     *        single menu option every line.
     * @see Menu
     */
    public static void showMenu(int menuIdx, int inlineTexts)
    {
        String[] menu = Menu.getMenuOptions(menuIdx);
        if (menu == null)
        {
            System.out.println("Invalid menu index given!");
        }
        else
        {
            String space = inlineTexts == 0 ? "" : "%-20s";
            String fmt = "[%d] " + space;
            int count = 0;
            for (String s : menu)
            {
                count++;
                System.out.printf(fmt, count, s);
                if (count % inlineTexts == 0)
                {
                    System.out.println();
                }
            }
        }
    }

    /**
     * Prompt some input to the user. Only receives on non-space containing String. This string can
     * then be parsed into targeted data type using DataTypeWrapper.parse() method.
     * 
     * @param phrase Prompt to the user.
     * @param inlineInput A flag to ask if the input is just one entire String or receive an entire
     *        line input. <br>
     *        Set to <b>true</b> if receiving only one String input without spaces. <br>
     *        Set to <b>false</b> if receiving an entire line of String input.
     * @return Value of the user's input.
     * @see Field#setFieldValue(String, boolean) How prompt is utilized in Field.
     */
    public static String prompt(String phrase, boolean inlineInput)
    {
        System.out.print(phrase);
        if (inlineInput)
        {
            String val = input.next();
            input.nextLine();
            return val;
        }
        return input.nextLine();
    }

    /**
     * Prompts user to set an option based on menu outputted.
     * 
     * @throws NumberFormatException May happen if the user attempts to input something other than
     *         numbers.
     */
    public static void setOption() throws NumberFormatException
    {
        option.setFieldValue("Select an option: ");
    }

    /**
     * @return Recently inputted option by the user.
     */
    public static int getOption()
    {
        return Main.option.getFieldValue();
    }

    /**
     * Used for printing the header whenever a new menu is accessed.
     * 
     * @param menuTitle Title of the menu to be outputted.
     */
    public static void showMenuHeader(String menuTitle)
    {
        System.out.printf("<---- %s ----->\n", menuTitle);
    }
}
