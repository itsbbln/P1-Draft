package Bank;
import Accounts.Account;
import java.util.ArrayList;

public class BankCredentialsComparator implements Comparator {

    public int compare(Account acc1, Account acc2) {
        // Check for null values
        String lastName1 = acc1.getOwnerLName() != null ? acc1.getOwnerLName() : "";
        String lastName2 = acc2.getOwnerLName() != null ? acc2.getOwnerLName() : "";
        String firstName1 = acc1.getOwnerFName() != null ? acc1.getOwnerFName() : "";
        String firstName2 = acc2.getOwnerFName() != null ? acc2.getOwnerFName() : "";

        // Compare by last name first
        int lastNameComparison = lastName1.compareTo(lastName2);
        if (lastNameComparison != 0) {
            return lastNameComparison;
        }
        // If last names are the same, sort by first name
        return firstName1.compareToIgnoreCase(firstName2);
    }

    // For checking duplicates
    public boolean isDuplicate(Account existingAccount, String ownerLName, String ownerFName, String ownerEmail, String pin) {
        return existingAccount.getOwnerLName().equalsIgnoreCase(ownerLName) &&
                existingAccount.getOwnerFName().equalsIgnoreCase(ownerFName) &&
                existingAccount.getPin().equals(pin) &&
                existingAccount.getOwnerEmail().equalsIgnoreCase(ownerEmail);
    }

    // Method to sort accounts
    public void sortAccounts(ArrayList<Account> accounts) {
        int n = accounts.size();
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                // Compare adjacent accounts using the comparator
                if (this.compare(accounts.get(j), accounts.get(j + 1)) > 0) {
                    // Swap accounts if they are in the wrong order
                    Account temp = accounts.get(j);
                    accounts.set(j, accounts.get(j + 1));
                    accounts.set(j + 1, temp);
                    swapped = true;
                }
            }
            // If no two elements were swapped in the inner loop, then the list is sorted
            if (!swapped) {
                break;
            }
        }
    }
}

