package Launcher;
import Accounts.Account;
import Bank.Bank;
import Bank.BankIdComparator;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;


public class BankLauncher {
    private static ArrayList<Bank> BANKS = new ArrayList<>();
    private static Bank loggedBank = null;

    public static List<Bank> getAllBanks() {
        return BANKS;
    }

    // Check if a user is logged in
    public static boolean isLoggedIn() {
        return loggedBank != null;
    }

    public static void bankInit() {
        System.out.println("\nBank operations initialized.");
    }

    // Show all accounts of the logged-in bank
    private static void showAccounts(Class<? extends Account> accountType) {
        if (loggedBank != null) {
            loggedBank.showAccounts(accountType);
        } else {
            System.out.println("\nNo bank is currently logged in.");
        }
    }

    // Add a new account to the logged-in bank
    private static void newAccounts(String accountType, String accountNumber, String ownerFName, String ownerLName, String ownerEmail, String pin, double initialDepositOrcreditLimit) {
        if (loggedBank != null) {
            if (accountType.equalsIgnoreCase("credit")) {
                loggedBank.createNewCreditAccount(accountNumber, ownerFName, ownerLName, ownerEmail, pin, initialDepositOrcreditLimit );
            }
            else if(accountType.equalsIgnoreCase("savings")) {
                loggedBank.createNewSavingsAccount(accountNumber, ownerFName, ownerLName, ownerEmail, pin, initialDepositOrcreditLimit);
            }
            else {
                System.out.println("\nInvalid account type.");
            }
        }
        else {
            System.out.println("\nNo bank is currently logged in.");
        }
    }

    // Bank login process
    public static boolean bankLogin(String name, String passcode) {
        for (Bank bank : BANKS) {
            if (bank.getName().equals(name) && bank.getPasscode().equals(passcode)) {
                loggedBank = bank;
                return true;
            }
        }
        return false; // Login failed
    }

    // Set logged-in bank
    private static void setLogSession(Bank b) {
        loggedBank = b;
    }

    // Logout from the bank
    public static void logout() {
        loggedBank = null;
    }

    // Create a new bank
    public static void createNewBank(String name, String passcode, double depositLimit, double withdrawLimit, double creditLimit, double processingFee) {
        int id = BANKS.size(); // Assigning unique ID based on size
        Bank newBank = new Bank(id, name, passcode, depositLimit, withdrawLimit, creditLimit, processingFee);
        addBank(newBank);
    }

    // Show all banks
    public static void showBanksMenu() {
        if (BANKS.isEmpty()) {
            System.out.println("\nNo banks available\n");
        } else {

            BANKS.sort(new BankIdComparator());
            for (Bank bank : BANKS) {
                System.out.println(bank);
            }
        }
    }

    // Add a bank to the list
    private static void addBank(Bank b) {
        BANKS.add(b);
    }

    // Get a bank using a comparator
    public static Bank getBank(Comparator<Bank> comparator, Bank bank) {
        for (Bank b : BANKS) {
            if (comparator.compare(b, bank) == 0) {
                return b;
            }
        }
        return null;
    }

    // Find an account by account number
    public static Account findAccount(String accountNum) {
        if (loggedBank != null) {
            return loggedBank.getBankAccount(accountNum);
        }
        else {
            System.out.println("\nNo bank is currently logged in");
            return null;
        }
    }

    // Get total number of banks
    public static int bankSize() {
        return BANKS.size();
    }

    //Getters
    public static void displayAccounts(Class<? extends Account> accountType) {
        showAccounts(accountType);
    }

    public static void newAccount(String accountType, String accountNumber, String ownerFName, String ownerLName, String ownerEmail, String pin, double initialDepositOrcreditLimit) { // public getter for newAccounts method
        if (loggedBank != null) {
            newAccounts(accountType, accountNumber, ownerFName, ownerLName, ownerEmail, pin, initialDepositOrcreditLimit);
        }
    }

    public static void LogSession(Bank bank) {
        setLogSession(bank);
    }

}
