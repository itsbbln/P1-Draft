package Launcher;

import Accounts.Account;
import Bank.Bank;
import Bank.BankComparator;
import java.util.List;

public class AccountLauncher {
    private Account loggedAccount;
    private Bank assocBank;

    private boolean isLogged() {
        return loggedAccount != null;
    }

    public void accountLogin(String accountNumber, String pin) {
        if (assocBank == null) {
            System.out.println("\nError: No bank selected. Please log in to a bank first.");
            return;
        }
        Account acc = checkCredentials(accountNumber, pin);
        if (acc != null) {
            setLoggedSession(acc);
            System.out.println("\nLogin successful. Welcome to your account, " + acc.getOwnerFullName() +".");

            // Verify if the session is actually set
            if (getLoggedAccount() == null) {
                System.out.println("\nError: Logged account is null after login.");
            } else {
                System.out.println("\nLogged account set successfully.");
            }
        } else {
            System.out.println("\nInvalid credentials. Please try again.");
        }
    }


    private Bank selectBank(String bankName) {
        Bank selectedBank = BankLauncher.getBank(new BankComparator(), new Bank(0, bankName, "", 0, 0, 0, 0));

        if (selectedBank == null) {
            System.out.println("\nBank not found!");
            return null; // Return null if no bank is found
        }

        System.out.println("\nSuccessfully logged into bank: " + selectedBank.getName() + "\n");

        // Assign selected bank to assocBank
        assocBank = selectedBank;

        // List accounts in the bank
        System.out.println("----- Current Accounts in " + selectedBank.getName() + " -----");
        List<Account> accounts = selectedBank.getBankAccounts();
        if (accounts == null || accounts.isEmpty()) { // Check if accounts list is null or empty
            System.out.println("\nNo accounts found in this bank.");
        } else {
            for (Account acc : accounts) {
                System.out.println("\nAccount Number: " + acc.getAccountNumber());
                System.out.println("Account Owner: " + acc.getOwnerFullName());
            }
        }

        return selectedBank;
    }

    void setLoggedSession(Account account) {
        this.loggedAccount = account;
    }

    private void destroyLoggedSession() {
        this.loggedAccount = null;
    }

    public Account checkCredentials(String accountNumber, String pin) {
        if (assocBank == null) return null; // No associated bank

        Account acc = assocBank.getBankAccount(accountNumber);
        if (acc == null) { // Check if account exists
            return null;
        }

        if (acc.ACCOUNTNUMBER.equals(accountNumber) && acc.getPin().equals(pin)) {
            return acc; // Credentials match

        }
        return null;
    }

    protected Account getLoggedAccount() {
        return this.loggedAccount;
    }

    public List<Bank> getAllBanks() {
        return BankLauncher.getAllBanks();
    }

    //Getters
    public Bank getSelectBank(String bankName){
        return selectBank(bankName);
    }

    public Account fetchLoggedAccount() {
        return getLoggedAccount();
    }

    public boolean getIsLogged(){
        return isLogged();
    }

    public void getDestroyLoggedSession(){
        destroyLoggedSession();
    }
}