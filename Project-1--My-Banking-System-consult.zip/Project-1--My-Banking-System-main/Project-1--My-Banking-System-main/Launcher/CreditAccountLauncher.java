package Launcher;
import Accounts.*;
import Bank.Bank;

public class CreditAccountLauncher extends AccountLauncher implements Payment {
    public void creditAccountInit() {
        CreditAccount account = getLoggedAccount();
        if (account == null) {
            System.out.println("\nError: No logged-in credit account.");
            return;
        }
        System.out.println("\nCredit Account operations initialized.");
    }

    private void creditPaymentProcess(String recipientAccountNumber, double amount) {
        CreditAccount creditAccount = getLoggedAccount();
        if (creditAccount == null) {
            System.out.println("\nNo logged-in credit account.");
            return;
        }

        // Retrieve the bank associated with the logged-in credit account
        Bank bank = creditAccount.getBank();
        if (bank == null) {
            System.out.println("\nError: Bank not found.");
            return;
        }

        Account recipientAccount = bank.getBankAccount(recipientAccountNumber);
        if (!(recipientAccount instanceof SavingsAccount)) {
            System.out.println("\nError: You can only send payments to a Savings Account.");
            return;
        }

        try {
            boolean success = creditAccount.pay(recipientAccount, amount);
            if (success) {
                System.out.println("\nCredit payment of $" + amount + " sent to account " + recipientAccount.getAccountNumber());
            } else {
                System.out.println("\nPayment failed. Check available credit and recipient details.");
            }
        } catch (IllegalAccountType e) {
            System.out.println("\nError: " + e.getMessage());
        }
    }

    private void creditRecompenseProcess(double amount) {
        CreditAccount creditAccount = getLoggedAccount();
        if (creditAccount == null) {
            System.out.println("\nNo logged-in credit account.");
            return;
        }

        if (amount <= 0 || amount > creditAccount.getCurrentDebt()) {
            System.out.println("\nInvalid recompense amount.");
            return;
        }

        creditAccount.recompense(amount);
        System.out.println("\nCredit recompense of " + amount + " processed. Remaining debt: " + creditAccount.getCurrentDebt());
    }

    @Override
    protected CreditAccount getLoggedAccount() {
        return (CreditAccount) super.getLoggedAccount();
    }

    @Override
    public void setLoggedSession(Account account) {
        super.setLoggedSession(account);
    }

    public void getCreditRecompenseProcess(double amount) {
        creditRecompenseProcess(amount);
    }

    public void getCreditPaymentProcess(String recipientAccountNumber, double amount) {
        creditPaymentProcess(recipientAccountNumber, amount);
    }

    public void makePayment(double amount) {
        CreditAccount creditAccount = getLoggedAccount();
        if (creditAccount == null) {
            System.out.println("\nNo logged-in credit account.");
            return;
        }

        creditAccount.makePayment(amount); // Delegate to the CreditAccount's makePayment method
    }

    @Override
    public boolean pay(Account account, double amount) throws IllegalAccountType {
        CreditAccount creditAccount = getLoggedAccount();
        if (creditAccount == null) {
            System.out.println("\nNo logged-in credit account.");
            return false;
        }

        return creditAccount.pay(account, amount); // Delegate to the CreditAccount's pay method
    }
}
