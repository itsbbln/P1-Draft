package Accounts;
import Bank.Bank;

public class SavingsAccount extends Account implements Deposit, Withdrawal, FundTransfer {
    private double balance;

    // Constructor
    public SavingsAccount(Bank bank, String accountNumber, String ownerFName, String ownerLName, String ownerEmail, String pin, double balance) {
        super(bank, accountNumber, ownerFName, ownerLName, ownerEmail, pin);
        this.balance = balance;
    }

    // Get balance statement
    public String getAccountBalanceStatement() {
        return "$" + balance;
    }

    // Check if enough balance for withdrawal
    private boolean hasEnoughBalance(double amount) {
        return balance >= amount;
    }

    // Handle insufficient balance scenario
    private void insufficientBalance() {
        System.out.println("\nError: Insufficient balance for this transaction.");
    }

    // Adjust balance (for deposits/withdrawals)
    private void adjustAccountBalance(double amount) {
        this.balance += amount;
    }

    // Implemented from abstract method in Account
    @Override
    public String toString() {
        return "\nAccount Number: " + getAccountNumber() +
         "\nOwner: " + getOwnerFullName() + "\nCurrent Balance: " + getAccountBalanceStatement();
    }

    @Override
    public boolean deposit(double amount) {
        if (amount > 0) {
            adjustAccountBalance(amount);
            addNewTransaction(getAccountNumber(), Transaction.Transactions.Deposit, "Deposited $" + amount);
            System.out.println("Deposited: $" + amount);
            return true;
        } else {
            System.out.println("\nInvalid deposit amount.");
            return false;
        }
    }

    @Override
    public boolean cashDeposit(double amount) {
        return deposit(amount);
    }

    @Override
    public boolean withdraw(double amount) {
        if (hasEnoughBalance(amount)) {
            adjustAccountBalance(-amount);
            addNewTransaction(getAccountNumber(), Transaction.Transactions.Withdraw, "Withdrawn $" + amount);
            System.out.println("Withdraw: $" + amount);
            return true;
        } else {
            insufficientBalance();
        }
        return false;
    }

    @Override
    public boolean withdrawal(double amount) {
        return withdraw(amount);
    }

    @Override
    public void transferFunds(double amount) {
        System.out.println("\nFund transfer requires recipient details.");
    }

    @Override
    public boolean transfer(Account recipient, double amount) throws IllegalAccountType {
        if (!(recipient instanceof SavingsAccount)) {
            throw new IllegalAccountType("\nInvalid recipient. Only savings accounts are allowed.");
        }

        if (withdraw(amount)) {
            ((SavingsAccount) recipient).deposit(amount);

            addNewTransaction(getAccountNumber(), Transaction.Transactions.FundTransfer,
                    "Transferred $" + amount + " to " + recipient.getAccountNumber());

            recipient.addNewTransaction(recipient.getAccountNumber(), Transaction.Transactions.FundTransfer,
                    "Received $" + amount + " from " + getAccountNumber());

            System.out.println("Transfer successful: $" + amount + " sent to " + recipient.getAccountNumber());
            return true;
        }
        System.out.println("\nTransfer failed.");
        return false;
    }

    @Override
    public boolean transfer(Bank bank, Account account, double amount) throws IllegalAccountType {
        if (!(account instanceof SavingsAccount)) {
            throw new IllegalAccountType("\nInvalid recipient. Only savings accounts are allowed.");
        }

        double totalAmount = amount + bank.getProcessingFee();

        if (!hasEnoughBalance(totalAmount)) {
            insufficientBalance();
            return false;
        }

        // Withdraw from source account (with processing fee)
        adjustAccountBalance(-totalAmount);

        // Deposit to recipient account
        ((SavingsAccount) account).deposit(amount);

        // Record transaction for sender
        addNewTransaction(getAccountNumber(), Transaction.Transactions.FundTransfer,
                "Transferred $" + amount + " to " + "[" + bank.getName() + " - " + account.getAccountNumber() + "]" + " with $" + bank.getProcessingFee() + " fee.");

        // Record transaction for recipient
        account.addNewTransaction(account.getAccountNumber(), Transaction.Transactions.FundTransfer,
                "\nReceived $" + amount + " from " + getAccountNumber() + ", " + getBank().getID());

        System.out.println("\nInter-bank transfer successful: $" + amount + " sent to " + account);
        return true;
    }

    @Override
    public String toString(String accountNum, Transaction type, String description) {
        return "Transaction: " + type + " | Account: " + accountNum + " | " + description;
    }
}

