package Bank;

import Accounts.Account;
import Accounts.AccountFactory;
import java.util.ArrayList;

public class Bank {
    private int ID;
    private String name, passcode;
    private double DEPOSITLIMIT, WITHDRAWLIMIT, CREDITLIMIT;
    private double processingFee;
    private ArrayList<Account> BANKACCOUNTS;

    // Overloaded Constructor
    public Bank(int ID, String name, String passcode) {
        this(ID, name, passcode, 0, 0, 0, 0);
    }

    // Constructor
    public Bank(int ID, String name, String passcode, double depositLimit, double withdrawLimit, double creditLimit, double processingFee) {
        this.ID = ID;
        this.name = name;
        this.passcode = passcode;
        this.DEPOSITLIMIT = depositLimit;
        this.WITHDRAWLIMIT = withdrawLimit;
        this.CREDITLIMIT = creditLimit;
        this.processingFee = processingFee;
        this.BANKACCOUNTS = new ArrayList<>();
    }

    public ArrayList<Account> createNewAccount() {
        return new ArrayList<>(BANKACCOUNTS);
    }

    // Create a new Credit Account using Dependency Injection
    public Account createNewAccount(AccountFactory factory, String accountNumber, String ownerFName, String ownerLName, String ownerEmail, String pin, double value) {
        Account newAccount = factory.createAccount(accountNumber, ownerFName, ownerLName, ownerEmail, pin, value);
        addNewAccount(newAccount);
        System.out.println("\nAccount created successfully! Your Account Number: " + accountNumber);
        return newAccount;
    }

    // Add an existing account
    public void addNewAccount(Account account) {
        BANKACCOUNTS.add(account);
        System.out.println("\nAccount added to bank: " + this.name);
    }

    // Static method to check if an account exists
    public static boolean accountExist(Bank bank, String accountNumber) {
        for (Account account : bank.BANKACCOUNTS) {
            if (account.getAccountNumber().equals(accountNumber)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "\nBank Name: " + name + " \nBank ID: " + ID;
    }

    // Getters
    public ArrayList<Account> getBankAccounts() {
        return BANKACCOUNTS;
    }

    public Account getBankAccount(String accountNumber) {
        for (Account account : BANKACCOUNTS) {
            if (account.getAccountNumber().equals(accountNumber)) {
                return account;
            }
        }
        return null;
    }

    public void showAccounts(Class<? extends Account> accountType) {
        System.out.println("\nShowing " + accountType.getSimpleName() + " Accounts:");
        for (Account account : BANKACCOUNTS) {
            if (accountType.isInstance(account)) {
                System.out.println("\nAccount Number: " + account.getAccountNumber());
                System.out.println("Account Owner: " + account.getOwnerFullName());
                System.out.println("Account Type: " + (account instanceof Accounts.CreditAccount ? "Credit" : "Savings"));
                System.out.println("--------------------------------");
            }
        }
    }

    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public String getPasscode() {
        return passcode;
    }

    public double getDepositLimit() {
        return DEPOSITLIMIT;
    }

    public double getWithdrawLimit() {
        return WITHDRAWLIMIT;
    }

    public double getCreditLimit() {
        return CREDITLIMIT;
    }

    public double getProcessingFee() {
        return processingFee;
    }
}
