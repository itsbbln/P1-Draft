package Bank;
import java.util.Comparator;

public class BankComparator implements Comparator<Bank> { // Use custom Comparator

    @Override
    public int compare(Bank b1, Bank b2) {
        return b1.getName().compareTo(b2.getName());
    }
}