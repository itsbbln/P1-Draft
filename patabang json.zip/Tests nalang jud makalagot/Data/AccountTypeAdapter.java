package Data;

import Accounts.Account;
import com.google.gson.*;

import java.lang.reflect.Type;

public class AccountTypeAdapter implements JsonSerializer<Account>, JsonDeserializer<Account> {
    
    @Override
    public JsonElement serialize(Account src, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject jsonObject = context.serialize(src).getAsJsonObject();
        jsonObject.addProperty("type", src.getClass().getSimpleName());
        return jsonObject;
    }

    @Override
    public Account deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        JsonObject jsonObject = json.getAsJsonObject();
        String type = jsonObject.get("type").getAsString();
        try {
            Class<?> clazz = Class.forName("Accounts." + type);
            return context.deserialize(json, clazz);
        } catch (ClassNotFoundException e) {
            throw new JsonParseException("Unknown element type: " + type, e);
        }
    }
}
