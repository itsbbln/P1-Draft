package Data;

import Accounts.Account;
import Bank.Bank;
import Transactions.Transaction;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.List;

public class DataManager {

    private static final String BANK_FILE = "bank.json";
    private static final String TRANSACTIONS_FILE = "transactions.csv";
    private static final String TEMP_SUFFIX = ".tmp";
    
    private static final Gson gson = new GsonBuilder()
            .setPrettyPrinting()
            .registerTypeAdapter(Account.class, new AccountTypeAdapter())
            .create();

    // Save bank and accounts to JSON file
    public static void saveBank(Bank bank) {
        File tempFile = new File(BANK_FILE + TEMP_SUFFIX);
        try (Writer writer = new FileWriter(tempFile)) {
            gson.toJson(bank, writer);
            Files.move(tempFile.toPath(), new File(BANK_FILE).toPath(), StandardCopyOption.REPLACE_EXISTING);
            System.out.println("✅ Bank data saved.");
        } catch (IOException e) {
            System.out.println("❌ Error saving bank data: " + e.getMessage());
        }
    }

    // Load bank and accounts from JSON file
    public static Bank loadBank() {
        File file = new File(BANK_FILE);
        if (!file.exists()) return new Bank();

        try (Reader reader = new FileReader(file)) {
            return gson.fromJson(
