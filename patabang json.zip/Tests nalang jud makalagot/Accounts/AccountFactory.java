package Accounts;

public interface AccountFactory {
    Account createAccount(String accountNumber, String ownerFName, String ownerLName, String ownerEmail, String pin, double value);
}
