package Accounts;

import Bank.Bank;

public class CreditAccountFactory implements AccountFactory {
    private Bank bank;

    public CreditAccountFactory(Bank bank) {
        this.bank = bank;
    }

    @Override
    public CreditAccount createAccount(String accountNumber, String ownerFName, String ownerLName, String ownerEmail, String pin, double creditLimit) {
        return new CreditAccount(bank, accountNumber, ownerFName, ownerLName, ownerEmail, pin, creditLimit);
    }
}
