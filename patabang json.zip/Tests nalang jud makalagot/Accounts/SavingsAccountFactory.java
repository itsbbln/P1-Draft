package Accounts;

import Bank.Bank;

public class SavingsAccountFactory implements AccountFactory {
    private Bank bank;

    public SavingsAccountFactory(Bank bank) {
        this.bank = bank;
    }

    @Override
    public SavingsAccount createAccount(String accountNumber, String ownerFName, String ownerLName, String ownerEmail, String pin, double value) {
        // Treat value as initial deposit
        return new SavingsAccount(bank, accountNumber, ownerFName, ownerLName, ownerEmail, pin, value);
    }
}
