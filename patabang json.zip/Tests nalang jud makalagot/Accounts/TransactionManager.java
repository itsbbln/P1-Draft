package Accounts;

public class TransactionManager {

    // Deposit funds
    public static boolean deposit(Account account, double amount) {
        if (amount <= 0) {
            System.out.println("\nInvalid deposit amount.");
            return false;
        }
        // Assuming account has a method to update balance
        if (account instanceof SavingsAccount) {
            ((SavingsAccount) account).updateBalance(amount);
            account.addNewTransaction(account.getAccountNumber(), Transaction.Transactions.Deposit, "Deposited: " + amount);
            System.out.println("\nDeposit successful!");
            return true;
        }
        System.out.println("\nDeposit failed.");
        return false;
    }

    // Withdraw funds
    public static boolean withdraw(Account account, double amount) {
        if (amount <= 0) {
            System.out.println("\nInvalid withdrawal amount.");
            return false;
        }
        if (account instanceof SavingsAccount) {
            SavingsAccount savingsAccount = (SavingsAccount) account;
            if (savingsAccount.getBalance() >= amount) {
                savingsAccount.updateBalance(-amount);
                account.addNewTransaction(account.getAccountNumber(), Transaction.Transactions.Withdraw, "Withdrew: " + amount);
                System.out.println("\nWithdrawal successful!");
                return true;
            } else {
                System.out.println("\nInsufficient balance.");
            }
        }
        return false;
    }

    // Transfer funds
    public static boolean transfer(Account fromAccount, Account toAccount, double amount) {
        if (amount <= 0 || fromAccount == toAccount) {
            System.out.println("\nInvalid transfer details.");
            return false;
        }
        if (withdraw(fromAccount, amount)) {
            deposit(toAccount, amount);
            fromAccount.addNewTransaction(fromAccount.getAccountNumber(), Transaction.Transactions.FundTransfer, 
                "Transferred: " + amount + " to " + toAccount.getAccountNumber());
            toAccount.addNewTransaction(toAccount.getAccountNumber(), Transaction.Transactions.FundTransfer, 
                "Received: " + amount + " from " + fromAccount.getAccountNumber());
            System.out.println("\nTransfer successful!");
            return true;
        }
        return false;
    }
}
