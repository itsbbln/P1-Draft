package Bank;
import Accounts.Account;

public class BankCredentialsComparator implements Comparator<Account> {

    // New method to check if an account with the same credentials exists
    public boolean compareCredentials(String lName, String fName, String pin, Account account) {
        return account.getOwnerLName().equals(lName) &&
                account.getOwnerFName().equals(fName) &&
                account.getPin().equals(pin);
    }

}
