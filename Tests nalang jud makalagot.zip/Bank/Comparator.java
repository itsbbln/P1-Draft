package Bank;

public interface Comparator<B> {
}
